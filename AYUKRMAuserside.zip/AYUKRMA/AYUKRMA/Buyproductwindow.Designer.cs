﻿
namespace AYUKRMA
{
    partial class Buyproductwindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buyproductwindow));
            this.panel7 = new System.Windows.Forms.Panel();
            this.Search = new Guna.UI.WinForms.GunaButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MORE = new Guna.UI.WinForms.GunaButton();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LOGOUT = new Guna.UI.WinForms.GunaButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.SELLPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.BUYPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.HOME = new Guna.UI.WinForms.GunaButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox4 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaElipsePanel1 = new Guna.UI.WinForms.GunaElipsePanel();
            this.label5 = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).BeginInit();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).BeginInit();
            this.gunaElipsePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.Search);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 80);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1240, 46);
            this.panel7.TabIndex = 16;
            // 
            // Search
            // 
            this.Search.AnimationHoverSpeed = 0.07F;
            this.Search.AnimationSpeed = 0.03F;
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.BorderColor = System.Drawing.Color.Black;
            this.Search.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Search.FocusedColor = System.Drawing.Color.Empty;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Image = ((System.Drawing.Image)(resources.GetObject("Search.Image")));
            this.Search.ImageSize = new System.Drawing.Size(20, 20);
            this.Search.Location = new System.Drawing.Point(1049, 6);
            this.Search.Name = "Search";
            this.Search.OnHoverBaseColor = System.Drawing.Color.White;
            this.Search.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Search.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.OnHoverImage = null;
            this.Search.OnPressedColor = System.Drawing.Color.Black;
            this.Search.Radius = 15;
            this.Search.Size = new System.Drawing.Size(208, 37);
            this.Search.TabIndex = 6;
            this.Search.Text = "Search Here";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 735);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1240, 10);
            this.panel8.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1240, 10);
            this.panel1.TabIndex = 14;
            // 
            // MORE
            // 
            this.MORE.AnimationHoverSpeed = 0.07F;
            this.MORE.AnimationSpeed = 0.03F;
            this.MORE.BackColor = System.Drawing.Color.Transparent;
            this.MORE.BaseColor = System.Drawing.Color.White;
            this.MORE.BorderColor = System.Drawing.Color.Black;
            this.MORE.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MORE.FocusedColor = System.Drawing.Color.Empty;
            this.MORE.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MORE.ForeColor = System.Drawing.Color.Black;
            this.MORE.Image = ((System.Drawing.Image)(resources.GetObject("MORE.Image")));
            this.MORE.ImageSize = new System.Drawing.Size(20, 20);
            this.MORE.Location = new System.Drawing.Point(923, 17);
            this.MORE.Name = "MORE";
            this.MORE.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.MORE.OnHoverBorderColor = System.Drawing.Color.Black;
            this.MORE.OnHoverForeColor = System.Drawing.Color.Black;
            this.MORE.OnHoverImage = null;
            this.MORE.OnPressedColor = System.Drawing.Color.Black;
            this.MORE.Radius = 8;
            this.MORE.Size = new System.Drawing.Size(127, 45);
            this.MORE.TabIndex = 6;
            this.MORE.Text = "MORE";
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.White;
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton1.Image")));
            this.gunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(1213, 6);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 8;
            this.gunaButton1.Size = new System.Drawing.Size(24, 24);
            this.gunaButton1.TabIndex = 2;
            this.gunaButton1.Text = " ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(1056, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 45);
            this.panel6.TabIndex = 5;
            // 
            // LOGOUT
            // 
            this.LOGOUT.AnimationHoverSpeed = 0.07F;
            this.LOGOUT.AnimationSpeed = 0.03F;
            this.LOGOUT.BackColor = System.Drawing.Color.Transparent;
            this.LOGOUT.BaseColor = System.Drawing.Color.White;
            this.LOGOUT.BorderColor = System.Drawing.Color.Black;
            this.LOGOUT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.LOGOUT.FocusedColor = System.Drawing.Color.Empty;
            this.LOGOUT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGOUT.ForeColor = System.Drawing.Color.Black;
            this.LOGOUT.Image = ((System.Drawing.Image)(resources.GetObject("LOGOUT.Image")));
            this.LOGOUT.ImageSize = new System.Drawing.Size(20, 20);
            this.LOGOUT.Location = new System.Drawing.Point(1065, 17);
            this.LOGOUT.Name = "LOGOUT";
            this.LOGOUT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.LOGOUT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverForeColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverImage = null;
            this.LOGOUT.OnPressedColor = System.Drawing.Color.Black;
            this.LOGOUT.Radius = 8;
            this.LOGOUT.Size = new System.Drawing.Size(142, 45);
            this.LOGOUT.TabIndex = 6;
            this.LOGOUT.Text = "LOGOUT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(914, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 45);
            this.panel5.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(704, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 45);
            this.panel4.TabIndex = 5;
            // 
            // SELLPRODUCT
            // 
            this.SELLPRODUCT.AnimationHoverSpeed = 0.07F;
            this.SELLPRODUCT.AnimationSpeed = 0.03F;
            this.SELLPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.SELLPRODUCT.BaseColor = System.Drawing.Color.White;
            this.SELLPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SELLPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.SELLPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SELLPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("SELLPRODUCT.Image")));
            this.SELLPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.SELLPRODUCT.Location = new System.Drawing.Point(713, 19);
            this.SELLPRODUCT.Name = "SELLPRODUCT";
            this.SELLPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.SELLPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverImage = null;
            this.SELLPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Radius = 8;
            this.SELLPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.SELLPRODUCT.TabIndex = 6;
            this.SELLPRODUCT.Text = "SELL PRODUCT";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(494, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 45);
            this.panel3.TabIndex = 3;
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.Black;
            this.gunaButton5.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton5.Image")));
            this.gunaButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(-19, 523);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Radius = 15;
            this.gunaButton5.Size = new System.Drawing.Size(71, 37);
            this.gunaButton5.TabIndex = 8;
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.Black;
            this.gunaButton6.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton6.Image")));
            this.gunaButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(-19, 566);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Radius = 15;
            this.gunaButton6.Size = new System.Drawing.Size(71, 37);
            this.gunaButton6.TabIndex = 9;
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.Black;
            this.gunaButton3.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton3.Image")));
            this.gunaButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(-19, 480);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 15;
            this.gunaButton3.Size = new System.Drawing.Size(71, 37);
            this.gunaButton3.TabIndex = 8;
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.Black;
            this.gunaButton4.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton4.Image")));
            this.gunaButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(-19, 437);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 15;
            this.gunaButton4.Size = new System.Drawing.Size(71, 37);
            this.gunaButton4.TabIndex = 9;
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.Black;
            this.gunaButton2.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton2.Image")));
            this.gunaButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(-19, 394);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 15;
            this.gunaButton2.Size = new System.Drawing.Size(71, 37);
            this.gunaButton2.TabIndex = 7;
            // 
            // BUYPRODUCT
            // 
            this.BUYPRODUCT.AnimationHoverSpeed = 0.07F;
            this.BUYPRODUCT.AnimationSpeed = 0.03F;
            this.BUYPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.BUYPRODUCT.BaseColor = System.Drawing.Color.White;
            this.BUYPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BUYPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.BUYPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUYPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("BUYPRODUCT.Image")));
            this.BUYPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.BUYPRODUCT.Location = new System.Drawing.Point(503, 17);
            this.BUYPRODUCT.Name = "BUYPRODUCT";
            this.BUYPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.BUYPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverImage = null;
            this.BUYPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Radius = 8;
            this.BUYPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.BUYPRODUCT.TabIndex = 4;
            this.BUYPRODUCT.Text = "BUY PRODUCT";
            // 
            // HOME
            // 
            this.HOME.AnimationHoverSpeed = 0.07F;
            this.HOME.AnimationSpeed = 0.03F;
            this.HOME.BackColor = System.Drawing.Color.Transparent;
            this.HOME.BaseColor = System.Drawing.Color.White;
            this.HOME.BorderColor = System.Drawing.Color.Black;
            this.HOME.DialogResult = System.Windows.Forms.DialogResult.None;
            this.HOME.FocusedColor = System.Drawing.Color.Empty;
            this.HOME.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HOME.ForeColor = System.Drawing.Color.Black;
            this.HOME.Image = ((System.Drawing.Image)(resources.GetObject("HOME.Image")));
            this.HOME.ImageSize = new System.Drawing.Size(20, 20);
            this.HOME.Location = new System.Drawing.Point(361, 19);
            this.HOME.Name = "HOME";
            this.HOME.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.HOME.OnHoverBorderColor = System.Drawing.Color.Black;
            this.HOME.OnHoverForeColor = System.Drawing.Color.Black;
            this.HOME.OnHoverImage = null;
            this.HOME.OnPressedColor = System.Drawing.Color.Black;
            this.HOME.Radius = 8;
            this.HOME.Size = new System.Drawing.Size(127, 45);
            this.HOME.TabIndex = 2;
            this.HOME.Text = "HOME";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.MORE);
            this.panel2.Controls.Add(this.gunaButton1);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.LOGOUT);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.SELLPRODUCT);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.BUYPRODUCT);
            this.panel2.Controls.Add(this.HOME);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1240, 70);
            this.panel2.TabIndex = 15;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(88, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(156, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.gunaButton6);
            this.panel9.Controls.Add(this.gunaButton3);
            this.panel9.Controls.Add(this.gunaButton5);
            this.panel9.Controls.Add(this.gunaButton4);
            this.panel9.Controls.Add(this.gunaButton2);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 126);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(55, 609);
            this.panel9.TabIndex = 21;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(1220, 126);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(20, 609);
            this.panel10.TabIndex = 22;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.gunaButton8);
            this.panel11.Controls.Add(this.gunaButton7);
            this.panel11.Controls.Add(this.panel16);
            this.panel11.Controls.Add(this.panel15);
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.gunaElipsePanel1);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Controls.Add(this.label2);
            this.panel11.Controls.Add(this.label1);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(55, 126);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1165, 609);
            this.panel11.TabIndex = 23;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.gunaCirclePictureBox4);
            this.panel16.Location = new System.Drawing.Point(78, 352);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(373, 166);
            this.panel16.TabIndex = 21;
            // 
            // gunaCirclePictureBox4
            // 
            this.gunaCirclePictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox4.Image")));
            this.gunaCirclePictureBox4.Location = new System.Drawing.Point(0, -97);
            this.gunaCirclePictureBox4.Name = "gunaCirclePictureBox4";
            this.gunaCirclePictureBox4.Size = new System.Drawing.Size(354, 260);
            this.gunaCirclePictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox4.TabIndex = 0;
            this.gunaCirclePictureBox4.TabStop = false;
            this.gunaCirclePictureBox4.UseTransfarantBackground = false;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.gunaCirclePictureBox2);
            this.panel15.Location = new System.Drawing.Point(260, 26);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(240, 109);
            this.panel15.TabIndex = 20;
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox2.Image")));
            this.gunaCirclePictureBox2.Location = new System.Drawing.Point(16, 3);
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.Size = new System.Drawing.Size(207, 195);
            this.gunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox2.TabIndex = 0;
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = false;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.gunaCirclePictureBox3);
            this.panel13.Location = new System.Drawing.Point(3, 26);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(240, 109);
            this.panel13.TabIndex = 19;
            // 
            // gunaCirclePictureBox3
            // 
            this.gunaCirclePictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox3.Image")));
            this.gunaCirclePictureBox3.Location = new System.Drawing.Point(16, 3);
            this.gunaCirclePictureBox3.Name = "gunaCirclePictureBox3";
            this.gunaCirclePictureBox3.Size = new System.Drawing.Size(207, 195);
            this.gunaCirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox3.TabIndex = 0;
            this.gunaCirclePictureBox3.TabStop = false;
            this.gunaCirclePictureBox3.UseTransfarantBackground = false;
            // 
            // gunaElipsePanel1
            // 
            this.gunaElipsePanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaElipsePanel1.BaseColor = System.Drawing.SystemColors.Control;
            this.gunaElipsePanel1.Controls.Add(this.label5);
            this.gunaElipsePanel1.Controls.Add(this.gunaCirclePictureBox1);
            this.gunaElipsePanel1.Location = new System.Drawing.Point(574, 36);
            this.gunaElipsePanel1.Name = "gunaElipsePanel1";
            this.gunaElipsePanel1.Size = new System.Drawing.Size(542, 548);
            this.gunaElipsePanel1.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 84);
            this.label5.TabIndex = 20;
            this.label5.Text = "Best \r\nSelling \r\nProducts\r\n";
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(84, 121);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(373, 360);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 9;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(283, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 63);
            this.label3.TabIndex = 16;
            this.label3.Text = "ඔබට අවශ්‍ය සියලු ආයුර්වේද \r\nනිශ්පාදන මිලදී ගැනීම සදහා\r\nපිවිසෙන්න.\r\n";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(302, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 23);
            this.label4.TabIndex = 15;
            this.label4.Text = "SPECIAL ORDERS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 63);
            this.label2.TabIndex = 11;
            this.label2.Text = "ඔබට අවශ්‍ය සියලු ආයුර්වේද \r\nනිශ්පාදන මිලදී ගැනීම සදහා\r\nපිවිසෙන්න.\r\n";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "BUY PRODUCT";
            // 
            // timer1
            // 
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // gunaButton7
            // 
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton7.ForeColor = System.Drawing.Color.Black;
            this.gunaButton7.Image = null;
            this.gunaButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton7.Location = new System.Drawing.Point(33, 280);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Radius = 15;
            this.gunaButton7.Size = new System.Drawing.Size(164, 37);
            this.gunaButton7.TabIndex = 10;
            this.gunaButton7.Text = "BUY PRODUCT";
            this.gunaButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaButton8
            // 
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton8.ForeColor = System.Drawing.Color.Black;
            this.gunaButton8.Image = null;
            this.gunaButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton8.Location = new System.Drawing.Point(299, 280);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Radius = 15;
            this.gunaButton8.Size = new System.Drawing.Size(164, 37);
            this.gunaButton8.TabIndex = 22;
            this.gunaButton8.Text = "SPECIAL ORDERS";
            this.gunaButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Buyproductwindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1240, 745);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Buyproductwindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buyproductwindow";
            this.panel7.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).EndInit();
            this.panel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).EndInit();
            this.gunaElipsePanel1.ResumeLayout(false);
            this.gunaElipsePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel7;
        private Guna.UI.WinForms.GunaButton Search;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton MORE;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaButton LOGOUT;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private Guna.UI.WinForms.GunaButton SELLPRODUCT;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private Guna.UI.WinForms.GunaButton BUYPRODUCT;
        private Guna.UI.WinForms.GunaButton HOME;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaElipsePanel gunaElipsePanel1;
        private System.Windows.Forms.Panel panel13;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel16;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox4;
        private System.Windows.Forms.Panel panel15;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private Guna.UI.WinForms.GunaButton gunaButton7;
    }
}