﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYUKRMA
{
    public partial class Buyproductwindow : Form
    {
        private bool isCollapsed;
        public Buyproductwindow() 
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(isCollapsed)
            {
                panel12.Height += 10;
                if(panel12.Size == panel12.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel12.Height -= 10;
                if (panel12.Size == panel12.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }

            }

        }

        private void gunaButton7_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }
    }
     
}
