﻿using DGVPrinterHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYUKRMA
{
    public partial class Orderwindow : Form
    {
      
        function fn = new function();
        string query;
        private int userID = 0;
       

        private SqlConnection con = new SqlConnection(@"Data Source =LAPTOP-85RN73DG; Database =AYUKARMA; Integrated Security = True");

        public Orderwindow(int id)
        {
            InitializeComponent();
            //gunaTextBox1.Text = str_value;
            this.userID = id;
        }

        public Orderwindow()
        {
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(" ");
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://touch.facebook.com/"); 
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/accounts/login/");
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/login?lang=en-gb");
        }

        private void gunaButton6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(" ");
        }

        private void gunaComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            String category = comboCategary.Text;
            query = "select NAME from " + gunaComboBox1.Text + " where Category2 = '" + category + "'";
            DataSet ds = fn.getData(query);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBox1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }

        //add catagory to list box 
        private void comboCategary_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        //add search process to list box 
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            

        }
        //selected item displayed in the form

        //count the price 
        private void txtQuantityUpDown_ValueChanged(object sender, EventArgs e)
        {

            
        }

        // remove cart item 
        int amount;
        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                amount = int.Parse(gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());

            }
            catch { }

        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            
        }


        //bill printer
        private void btnPrint_Click(object sender, EventArgs e)
        {
            

        }

        // add to cart & check minimum quantity
        protected int n, total = 0;



        //add the table
        private void GunaComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            txtQuantityUpDown.ResetText();
            txtTotel.Clear();

            String text = listBox1.GetItemText(listBox1.SelectedItem);
            string table = gunaComboBox1.Text;
            txtItemName.Text = text;
            query = "select Price from " + table + " where NAME = '" + text + "'";
            DataSet ds = fn.getData(query);

            try
            {
                txtPrice.Text = ds.Tables[0].Rows[0][0].ToString();
            }
            catch { }
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
          

        }

        private void comboCategary_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string table = gunaComboBox1.Text;
            String category = comboCategary.Text;
            query = "select NAME from " + table + " where Category2 = '" + category + "'";
            DataSet ds = fn.getData(query);


            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBox1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string table = gunaComboBox1.Text;
            String category = comboCategary.Text;
            query = "select NAME from " + table + " where Category2 ='" + category + "' and NAME like '" + txtSearch.Text + " % '";
            DataSet ds = fn.getData(query);


            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBox1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
            }
        }

        private void gunaTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtItemName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantityUpDown_ValueChanged_1(object sender, EventArgs e)
        {
            Int64 quan = Int64.Parse(txtQuantityUpDown.Value.ToString());
            Int64 price = Int64.Parse(txtPrice.Text);
            txtTotel.Text = (quan * price).ToString();

        }

        private void txtTotel_TextChanged(object sender, EventArgs e)
        {

        }

        

        /*public string UserID(TextBox username )
        {
            query = "Select UserID from USERS where Username = '" + username.Text + "' ";
            DataSet ds = fn.getData(query);
        }*/

        private void btnAddtoCart_Click_1(object sender, EventArgs e)
        {
            setCart();
        }

        private void setCart()
        {
            string que = "Insert into Cart (UserID,ProductName,Unitprice,Totalprice,Quantity) Values (" + userID + ",'" + txtItemName.Text + "', '" + txtPrice.Text + "','" + txtTotel.Text + "'," + txtQuantityUpDown.Text + ") ";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
            loadDataView();
        }

        private void loadDataView()
        {
            string table = "cart";
            string que = "SELECT * FROM Cart  WHERE UserID LIKE '%" + userID + "%'";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                gunaDataGridView1.DataSource = ds;
                gunaDataGridView1.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            try
            {
                gunaDataGridView1.Rows.RemoveAt(this.gunaDataGridView1.SelectedRows[0].Index);
            }
            catch { }
            total -= amount;
            labelTotelAmount.Text = "Rs. " + total;
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void gunaTextBox1_TextChanged_1(object sender, EventArgs e)
        {
            loadDataView();
        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click_1(object sender, EventArgs e)
        {
            {   
                
                for (int i = 0; i < gunaDataGridView1.Rows.Count; i++)
                {
                    query = "INSERT INTO Orders (UserID,ProductName,Unitprice,Totalprice,Quantity) VALUES (" + userID + "," + gunaDataGridView1.Rows[i].Cells[0].Value + ", " + gunaDataGridView1.Rows[i].Cells[1].Value + "," + gunaDataGridView1.Rows[i].Cells[2].Value + "," + gunaDataGridView1.Rows[i].Cells[3].Value + ");";
                    fn.setData(query);
                    
                }
            }

            {
                DGVPrinter printer = new DGVPrinter();
                printer.Title = "Ayukarma Customer Bill";
                printer.SubTitle = string.Format("Date: {0}", DateTime.Now.Date);
                printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
                printer.PageNumbers = true;
                printer.PageNumberInHeader = false;
                printer.PorportionalColumns = true;
                printer.HeaderCellAlignment = StringAlignment.Near;
                printer.Footer = "Total Payable Amount: " + labelTotelAmount.Text;
                printer.FooterSpacing = 15;
                printer.PrintDataGridView(gunaDataGridView1);

                total = 0;
                gunaDataGridView1.Rows.Clear();
                labelTotelAmount.Text = "Rs. " + total;
            }
        }
    }

   
}
