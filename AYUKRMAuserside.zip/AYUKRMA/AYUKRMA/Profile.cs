﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Profile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-94BM1CMP;Initial Catalog=USER;Integrated Security=True");
        SqlCommand command;
        string imgLoc = "";

        //private void Show_Data()
        //{
        //    SqlConnection con = new SqlConnection("Data Source=LAPTOP-94BM1CMP;Initial Catalog=USER;Integrated Security=True");
        //    try
        //    {

        //        con.Open();
        //        SqlDataAdapter da = new SqlDataAdapter("select * from PROFILE", con);
        //        DataTable dt = new DataTable();
        //        da.Fill(dt);
        //        dataGridView1.DataSource = dt;
        //        con.Close();
        //        dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}
        private void Form1_Load(object sender, EventArgs e)
        {
            //Show_Data();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {

            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "JPG Files(*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files(*.*)|*.*";
                dlg.Title = "Select PROFILE Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    imgLoc = dlg.FileName.ToString();
                    gunaCirclePictureBox1.ImageLocation = imgLoc;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "SELECT FIRST_NAME,LAST_NAME,EMAIL,TEL_NUMBER,STATE,IMAGE FROM PROFILE WHERE ID = " + gunaTextBox1.Text + "";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                command = new SqlCommand(sql, conn);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    gunaTextBox2.Text = reader[0].ToString();
                    gunaTextBox3.Text = reader[1].ToString();
                    gunaTextBox4.Text = reader[2].ToString();
                    gunaTextBox5.Text = reader[3].ToString();
                    gunaComboBox1.Text = reader[4].ToString();
                    byte[] img = (byte[])(reader[5]);
                    if (img == null)
                        gunaCirclePictureBox1.Image = null;
                    else
                    {
                        MemoryStream ms = new MemoryStream(img);
                        gunaCirclePictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {

                    gunaTextBox2.Text = "";
                    gunaTextBox3.Text = "";
                    gunaTextBox4.Text = "";
                    gunaTextBox5.Text = "";
                    gunaComboBox1.Text = null;
                    gunaCirclePictureBox1.Image = null;
                    MessageBox.Show("This is dose not exist.");
                }
                conn.Close();


            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] img = null;
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img = br.ReadBytes((int)fs.Length);
                string sql = "INSERT INTO PROFILE(ID,FIRST_NAME,LAST_NAME,EMAIL,TEL_NUMBER,STATE,IMAGE) VALUES ('" + gunaTextBox1.Text + "','" + gunaTextBox2.Text + "','" + gunaTextBox3.Text + "','" + gunaTextBox4.Text + "','" + gunaTextBox5.Text + "','" + gunaComboBox1.Text + "',@img)";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                command = new SqlCommand(sql, conn);
                command.Parameters.Add(new SqlParameter("@img", img));
                int x = command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("data inserted");
                gunaTextBox1.Text = "";
                gunaTextBox2.Text = "";
                gunaTextBox3.Text = "";
                gunaTextBox4.Text = "";
                gunaTextBox5.Text = "";
                gunaComboBox1.Text = null;
                gunaCirclePictureBox1.Image = null;

            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
        }
    
        private void gunaButton2_Click(object sender, EventArgs e)
        {
            try
            {


                //byte[] img = null;
                //FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                //BinaryReader br = new BinaryReader(fs);
                //img = br.ReadBytes((int)fs.Length);
                conn.Open();
                SqlCommand command = new SqlCommand("UPDATE PROFILE SET FIRST_NAME='" + gunaTextBox2.Text + "',LAST_NAME='" + gunaTextBox3.Text + "',EMAIL='" + gunaTextBox4.Text + "',TEL_NUMBER='" + gunaTextBox5.Text + "',STATE='" + gunaComboBox1.Text + "' WHERE ID='" + gunaTextBox1.Text + "' ",conn);
                //SqlCommand command = new SqlCommand("UPDATE PROFILE SET FIRST_NAME=@fn,LAST_NAME=@ln,EMAIL=@email,TEL_NUMBER=@tel,STATE=@state,IMAGE=@img WHERE ID='" + gunaTextBox1.Text + "' ", conn);
                command.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Successfully Updated.");

               
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
           
        }

        private void gunaButton9_Click(object sender, EventArgs e)
        {

        }
    }
}
