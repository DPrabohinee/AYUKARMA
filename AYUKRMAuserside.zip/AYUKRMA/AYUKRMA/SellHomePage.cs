﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AyukarmaFinal
{
    public partial class SellHomePage : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-R8SRBBL;Initial Catalog=AYU;Integrated Security=True;User ID= ;Password= ");
        SqlConnection conn1 = new SqlConnection(@"Data Source=DESKTOP-R8SRBBL;Initial Catalog=AYU;Integrated Security=True;User ID= ;Password= ");
        String activeNIC = "123";

        public SellHomePage()
        {
            InitializeComponent();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            SellPage sp = new SellPage();
            sp.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            

        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd1 = new SqlCommand("SELECT Position FROM dbo.USERS WHERE NICNo='" + activeNIC + "'", conn);

            SqlDataReader rdr = null;
            conn.Open();
            rdr = cmd1.ExecuteReader();

            while (rdr.Read())
            {
                int seller = (int)rdr["Position"];

                if (seller == 0)
                {
                    MessageBox.Show("Only sellers are allowed to enter. Publish an advertisement to become a seller.");
                }
                else
                {
                    SellPage sp = new SellPage();
                    sp.Show();
                }

            }
            rdr.Close();
            conn.Close();
        }
    }
}
