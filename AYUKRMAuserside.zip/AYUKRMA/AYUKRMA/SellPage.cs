﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AyukarmaFinal
{
    public partial class SellPage : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-R8SRBBL;Initial Catalog=AYU;Integrated Security=True;User ID= ;Password= ");
        SqlConnection conn1 = new SqlConnection(@"Data Source=DESKTOP-R8SRBBL;Initial Catalog=AYU;Integrated Security=True;User ID= ;Password= ");
        String activeNIC="456";

        public SellPage()
        {
            InitializeComponent();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (String.IsNullOrEmpty(nametb.Text))
            {
                setLabel(namelbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(categorycb.Text))
            {
                setLabel(categorylbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(pricetb.Text))
            {
                setLabel(pricelbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(quantitytb.Text))
            {
                setLabel(quantitylbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(unitcb.Text))
            {
                setLabel(unitlbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(addresstb.Text))
            {
                setLabel(addresslbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(telephonetb.Text))
            {
                setLabel(telephonelbl, "Required");
            }
            else
            {
                if (telephonetb.Text.Length != 10)
                {
                    setLabel(telephonelbl, "Please enter a valid telephone number");
                }
                else
                {
                    count += 1;
                }

            }

            if (count == 7)
            {
                SqlCommand cmd1 = new SqlCommand("SELECT Position FROM dbo.USERS WHERE NICNo='" + activeNIC + "'", conn);

                SqlDataReader rdr = null;
                conn.Open();
                rdr = cmd1.ExecuteReader();

                while (rdr.Read())
                {
                    int seller = (int)rdr["Position"];

                    if (seller == 0)
                    {
                        try
                        {
                            var confirmResult = MessageBox.Show("If you proceed you will be recorded in our system as a seller. Are you sure you want to proceed?",
                                         "Confirmation Message",
                                         MessageBoxButtons.YesNo);
                            if (confirmResult == DialogResult.Yes)
                            {
                                try
                                {
                                    SqlCommand cmd2 = new SqlCommand("UPDATE dbo.USERS SET Position = 1 WHERE NICNo='" + activeNIC + "'", conn1);
                                    conn1.Open();
                                    int a = cmd2.ExecuteNonQuery();
                                    conn1.Close();

                                    if (a == 1)
                                    {
                                        try
                                        {
                                            String query = "INSERT INTO dbo.Selling (NICNo, Item, Price, Quantity, Unit, Address, Telephone) VALUES ('" + activeNIC + "','" + nametb.Text + "'," + pricetb.Text + "," + quantitytb.Text + ",'" + unitcb.Text + "','" + addresstb.Text + "'," + Int32.Parse(telephonetb.Text) + ")";
                                            SqlCommand cmd = new SqlCommand(query, conn1);
                                            conn1.Open();
                                            cmd.ExecuteNonQuery();
                                            conn1.Close();
                                        }
                                        catch (Exception ex)
                                        {

                                            MessageBox.Show(ex.Message);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {

                                    MessageBox.Show(ex.Message);
                                }
                            }
                            else
                            {
                                // If 'No', do something here.
                            }
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }

                    }
                    else
                    {
                        try
                        {
                            String query = "INSERT INTO dbo.Selling (NICNo, Item, Price, Quantity, Unit, Address, Telephone, ImageName1, ImageName2, ImageName3, ImageName4, ImageName5) VALUES ('" + activeNIC + "','" + nametb.Text + "'," + pricetb.Text + "," + quantitytb.Text + ",'" + unitcb.Text + "','" + addresstb.Text + "'," + Int32.Parse(telephonetb.Text) + "," +textBox1.Text+ "," + textBox2.Text + "," + textBox3.Text + "," + textBox4.Text + "," + textBox5.Text + ")";
                            SqlCommand cmd = new SqlCommand(query, conn1);
                            conn1.Open();
                            cmd.ExecuteNonQuery();
                            conn1.Close();
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(ex.Message);
                        }
                    }

                }
                rdr.Close();
                conn.Close();
            }

            
            
        }

        private void SellHomePage_Load(object sender, EventArgs e)
        {
            
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "JPG Files(*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files(*.*)|*.*";
                dlg.Title = "Select PROFILE Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    imgLoc.Text = dlg.FileName.ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void setLabel(Label mylab, String message)
        {
            // Creating and setting the label 
            mylab.Text = message;
            mylab.Font = new Font("Calibri", 8);
            mylab.ForeColor = Color.Red;
        }

        private void gunaButton1_Click_1(object sender, EventArgs e)
        {
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // image file path  
                textBox1.Text = open.FileName;
            }
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // image file path  
                textBox2.Text = open.FileName;
            }
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // image file path  
                textBox3.Text = open.FileName;
            }
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // image file path  
                textBox4.Text = open.FileName;
            }
        }

        private void gunaButton6_Click(object sender, EventArgs e)
        {
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // image file path  
                textBox5.Text = open.FileName;
            }
        }
    }
}
