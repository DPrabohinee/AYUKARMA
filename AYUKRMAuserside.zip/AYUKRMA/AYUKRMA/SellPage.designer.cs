﻿
namespace AyukarmaFinal
{
    partial class SellPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellPage));
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.nametb = new System.Windows.Forms.TextBox();
            this.pricetb = new System.Windows.Forms.TextBox();
            this.quantitytb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.categorycb = new System.Windows.Forms.ComboBox();
            this.unitcb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.addresstb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.telephonetb = new System.Windows.Forms.TextBox();
            this.namelbl = new System.Windows.Forms.Label();
            this.categorylbl = new System.Windows.Forms.Label();
            this.pricelbl = new System.Windows.Forms.Label();
            this.quantitylbl = new System.Windows.Forms.Label();
            this.unitlbl = new System.Windows.Forms.Label();
            this.addresslbl = new System.Windows.Forms.Label();
            this.telephonelbl = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.MORE = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LOGOUT = new Guna.UI.WinForms.GunaButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.SELLPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.BUYPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.HOME = new Guna.UI.WinForms.GunaButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Search = new Guna.UI.WinForms.GunaButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton12 = new Guna.UI.WinForms.GunaButton();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(958, 569);
            this.gunaButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 10;
            this.gunaButton2.Size = new System.Drawing.Size(219, 39);
            this.gunaButton2.TabIndex = 11;
            this.gunaButton2.Text = "Publish Advertisement";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // nametb
            // 
            this.nametb.Location = new System.Drawing.Point(852, 223);
            this.nametb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nametb.Name = "nametb";
            this.nametb.Size = new System.Drawing.Size(325, 22);
            this.nametb.TabIndex = 13;
            // 
            // pricetb
            // 
            this.pricetb.Location = new System.Drawing.Point(852, 335);
            this.pricetb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pricetb.Name = "pricetb";
            this.pricetb.Size = new System.Drawing.Size(325, 22);
            this.pricetb.TabIndex = 16;
            // 
            // quantitytb
            // 
            this.quantitytb.Location = new System.Drawing.Point(852, 388);
            this.quantitytb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.quantitytb.Name = "quantitytb";
            this.quantitytb.Size = new System.Drawing.Size(176, 22);
            this.quantitytb.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(534, 206);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 40);
            this.label1.TabIndex = 19;
            this.label1.Text = "Name of the Item :\r\nවිකුණන ද්‍රව්‍යයේ / නිෂ්පාදනයේ නම :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(534, 372);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 40);
            this.label2.TabIndex = 20;
            this.label2.Text = "Available Quantity :\r\nපවතින ප්‍රමාණය :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(534, 318);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(283, 40);
            this.label3.TabIndex = 21;
            this.label3.Text = "Price of the Item :\r\nවිකුණන ද්‍රව්‍යයේ / නිෂ්පාදනයේ මිල :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(534, 264);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 40);
            this.label4.TabIndex = 22;
            this.label4.Text = "Category :\r\nවර්ගය :";
            // 
            // categorycb
            // 
            this.categorycb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.categorycb.FormattingEnabled = true;
            this.categorycb.Items.AddRange(new object[] {
            "Raw Material | අමුදව්ය",
            "Product | නිෂ්පාදන"});
            this.categorycb.Location = new System.Drawing.Point(852, 280);
            this.categorycb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.categorycb.Name = "categorycb";
            this.categorycb.Size = new System.Drawing.Size(325, 24);
            this.categorycb.TabIndex = 23;
            // 
            // unitcb
            // 
            this.unitcb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.unitcb.FormattingEnabled = true;
            this.unitcb.Items.AddRange(new object[] {
            "grams",
            "ml",
            "piece"});
            this.unitcb.Location = new System.Drawing.Point(1056, 388);
            this.unitcb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.unitcb.Name = "unitcb";
            this.unitcb.Size = new System.Drawing.Size(121, 24);
            this.unitcb.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(534, 425);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 40);
            this.label5.TabIndex = 29;
            this.label5.Text = "Address :\r\nලිපිනය :";
            // 
            // addresstb
            // 
            this.addresstb.Location = new System.Drawing.Point(852, 442);
            this.addresstb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addresstb.Multiline = true;
            this.addresstb.Name = "addresstb";
            this.addresstb.Size = new System.Drawing.Size(325, 24);
            this.addresstb.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(534, 480);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 40);
            this.label6.TabIndex = 31;
            this.label6.Text = "Contact number :\r\nඇමතුම් අංකය :";
            // 
            // telephonetb
            // 
            this.telephonetb.Location = new System.Drawing.Point(852, 498);
            this.telephonetb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.telephonetb.Name = "telephonetb";
            this.telephonetb.Size = new System.Drawing.Size(325, 22);
            this.telephonetb.TabIndex = 30;
            // 
            // namelbl
            // 
            this.namelbl.AutoSize = true;
            this.namelbl.Location = new System.Drawing.Point(850, 241);
            this.namelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.namelbl.Name = "namelbl";
            this.namelbl.Size = new System.Drawing.Size(0, 17);
            this.namelbl.TabIndex = 32;
            // 
            // categorylbl
            // 
            this.categorylbl.AutoSize = true;
            this.categorylbl.Location = new System.Drawing.Point(850, 299);
            this.categorylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.categorylbl.Name = "categorylbl";
            this.categorylbl.Size = new System.Drawing.Size(0, 17);
            this.categorylbl.TabIndex = 33;
            // 
            // pricelbl
            // 
            this.pricelbl.AutoSize = true;
            this.pricelbl.Location = new System.Drawing.Point(850, 355);
            this.pricelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricelbl.Name = "pricelbl";
            this.pricelbl.Size = new System.Drawing.Size(0, 17);
            this.pricelbl.TabIndex = 34;
            // 
            // quantitylbl
            // 
            this.quantitylbl.AutoSize = true;
            this.quantitylbl.Location = new System.Drawing.Point(850, 407);
            this.quantitylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quantitylbl.Name = "quantitylbl";
            this.quantitylbl.Size = new System.Drawing.Size(0, 17);
            this.quantitylbl.TabIndex = 35;
            // 
            // unitlbl
            // 
            this.unitlbl.AutoSize = true;
            this.unitlbl.Location = new System.Drawing.Point(1052, 368);
            this.unitlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.unitlbl.Name = "unitlbl";
            this.unitlbl.Size = new System.Drawing.Size(0, 17);
            this.unitlbl.TabIndex = 36;
            // 
            // addresslbl
            // 
            this.addresslbl.AutoSize = true;
            this.addresslbl.Location = new System.Drawing.Point(850, 462);
            this.addresslbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(0, 17);
            this.addresslbl.TabIndex = 37;
            // 
            // telephonelbl
            // 
            this.telephonelbl.AutoSize = true;
            this.telephonelbl.Location = new System.Drawing.Point(850, 517);
            this.telephonelbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.telephonelbl.Name = "telephonelbl";
            this.telephonelbl.Size = new System.Drawing.Size(0, 17);
            this.telephonelbl.TabIndex = 38;
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(254, 157);
            this.gunaButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 10;
            this.gunaButton1.Size = new System.Drawing.Size(219, 39);
            this.gunaButton1.TabIndex = 39;
            this.gunaButton1.Text = "Add Image 1";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click_1);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(83, 172);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(149, 22);
            this.textBox1.TabIndex = 40;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(83, 229);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(149, 22);
            this.textBox2.TabIndex = 41;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(83, 284);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(149, 22);
            this.textBox3.TabIndex = 42;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(83, 337);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(149, 22);
            this.textBox4.TabIndex = 43;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(83, 391);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(149, 22);
            this.textBox5.TabIndex = 44;
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.White;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(254, 215);
            this.gunaButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 10;
            this.gunaButton3.Size = new System.Drawing.Size(219, 39);
            this.gunaButton3.TabIndex = 45;
            this.gunaButton3.Text = "Add Image 2";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton3.Click += new System.EventHandler(this.gunaButton3_Click);
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.White;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(254, 269);
            this.gunaButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 10;
            this.gunaButton4.Size = new System.Drawing.Size(219, 39);
            this.gunaButton4.TabIndex = 46;
            this.gunaButton4.Text = "Add Image 3";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.White;
            this.gunaButton5.Image = null;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(254, 327);
            this.gunaButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Radius = 10;
            this.gunaButton5.Size = new System.Drawing.Size(219, 39);
            this.gunaButton5.TabIndex = 47;
            this.gunaButton5.Text = "Add Image 4";
            this.gunaButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.White;
            this.gunaButton6.Image = null;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(254, 380);
            this.gunaButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Radius = 10;
            this.gunaButton6.Size = new System.Drawing.Size(219, 39);
            this.gunaButton6.TabIndex = 48;
            this.gunaButton6.Text = "Add Image 5";
            this.gunaButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(704, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 45);
            this.panel4.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(494, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 45);
            this.panel3.TabIndex = 3;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(88, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(156, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.MORE);
            this.panel2.Controls.Add(this.gunaButton7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.LOGOUT);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.SELLPRODUCT);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.BUYPRODUCT);
            this.panel2.Controls.Add(this.HOME);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1240, 70);
            this.panel2.TabIndex = 49;
            // 
            // MORE
            // 
            this.MORE.AnimationHoverSpeed = 0.07F;
            this.MORE.AnimationSpeed = 0.03F;
            this.MORE.BackColor = System.Drawing.Color.Transparent;
            this.MORE.BaseColor = System.Drawing.Color.White;
            this.MORE.BorderColor = System.Drawing.Color.Black;
            this.MORE.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MORE.FocusedColor = System.Drawing.Color.Empty;
            this.MORE.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MORE.ForeColor = System.Drawing.Color.Black;
            this.MORE.Image = ((System.Drawing.Image)(resources.GetObject("MORE.Image")));
            this.MORE.ImageSize = new System.Drawing.Size(20, 20);
            this.MORE.Location = new System.Drawing.Point(923, 17);
            this.MORE.Name = "MORE";
            this.MORE.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.MORE.OnHoverBorderColor = System.Drawing.Color.Black;
            this.MORE.OnHoverForeColor = System.Drawing.Color.Black;
            this.MORE.OnHoverImage = null;
            this.MORE.OnPressedColor = System.Drawing.Color.Black;
            this.MORE.Radius = 8;
            this.MORE.Size = new System.Drawing.Size(127, 45);
            this.MORE.TabIndex = 6;
            this.MORE.Text = "MORE";
            // 
            // gunaButton7
            // 
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.White;
            this.gunaButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton7.ForeColor = System.Drawing.Color.White;
            this.gunaButton7.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton7.Image")));
            this.gunaButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton7.Location = new System.Drawing.Point(1213, 6);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Radius = 8;
            this.gunaButton7.Size = new System.Drawing.Size(24, 24);
            this.gunaButton7.TabIndex = 2;
            this.gunaButton7.Text = " ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(1056, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 45);
            this.panel6.TabIndex = 5;
            // 
            // LOGOUT
            // 
            this.LOGOUT.AnimationHoverSpeed = 0.07F;
            this.LOGOUT.AnimationSpeed = 0.03F;
            this.LOGOUT.BackColor = System.Drawing.Color.Transparent;
            this.LOGOUT.BaseColor = System.Drawing.Color.White;
            this.LOGOUT.BorderColor = System.Drawing.Color.Black;
            this.LOGOUT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.LOGOUT.FocusedColor = System.Drawing.Color.Empty;
            this.LOGOUT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGOUT.ForeColor = System.Drawing.Color.Black;
            this.LOGOUT.Image = ((System.Drawing.Image)(resources.GetObject("LOGOUT.Image")));
            this.LOGOUT.ImageSize = new System.Drawing.Size(20, 20);
            this.LOGOUT.Location = new System.Drawing.Point(1065, 17);
            this.LOGOUT.Name = "LOGOUT";
            this.LOGOUT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.LOGOUT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverForeColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverImage = null;
            this.LOGOUT.OnPressedColor = System.Drawing.Color.Black;
            this.LOGOUT.Radius = 8;
            this.LOGOUT.Size = new System.Drawing.Size(142, 45);
            this.LOGOUT.TabIndex = 6;
            this.LOGOUT.Text = "LOGOUT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(914, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 45);
            this.panel5.TabIndex = 7;
            // 
            // SELLPRODUCT
            // 
            this.SELLPRODUCT.AnimationHoverSpeed = 0.07F;
            this.SELLPRODUCT.AnimationSpeed = 0.03F;
            this.SELLPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.SELLPRODUCT.BaseColor = System.Drawing.Color.White;
            this.SELLPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SELLPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.SELLPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SELLPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("SELLPRODUCT.Image")));
            this.SELLPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.SELLPRODUCT.Location = new System.Drawing.Point(713, 19);
            this.SELLPRODUCT.Name = "SELLPRODUCT";
            this.SELLPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.SELLPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverImage = null;
            this.SELLPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Radius = 8;
            this.SELLPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.SELLPRODUCT.TabIndex = 6;
            this.SELLPRODUCT.Text = "SELL PRODUCT";
            // 
            // BUYPRODUCT
            // 
            this.BUYPRODUCT.AnimationHoverSpeed = 0.07F;
            this.BUYPRODUCT.AnimationSpeed = 0.03F;
            this.BUYPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.BUYPRODUCT.BaseColor = System.Drawing.Color.White;
            this.BUYPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BUYPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.BUYPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUYPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("BUYPRODUCT.Image")));
            this.BUYPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.BUYPRODUCT.Location = new System.Drawing.Point(503, 17);
            this.BUYPRODUCT.Name = "BUYPRODUCT";
            this.BUYPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.BUYPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverImage = null;
            this.BUYPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Radius = 8;
            this.BUYPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.BUYPRODUCT.TabIndex = 4;
            this.BUYPRODUCT.Text = "BUY PRODUCT";
            // 
            // HOME
            // 
            this.HOME.AnimationHoverSpeed = 0.07F;
            this.HOME.AnimationSpeed = 0.03F;
            this.HOME.BackColor = System.Drawing.Color.Transparent;
            this.HOME.BaseColor = System.Drawing.Color.White;
            this.HOME.BorderColor = System.Drawing.Color.Black;
            this.HOME.DialogResult = System.Windows.Forms.DialogResult.None;
            this.HOME.FocusedColor = System.Drawing.Color.Empty;
            this.HOME.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HOME.ForeColor = System.Drawing.Color.Black;
            this.HOME.Image = ((System.Drawing.Image)(resources.GetObject("HOME.Image")));
            this.HOME.ImageSize = new System.Drawing.Size(20, 20);
            this.HOME.Location = new System.Drawing.Point(361, 19);
            this.HOME.Name = "HOME";
            this.HOME.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.HOME.OnHoverBorderColor = System.Drawing.Color.Black;
            this.HOME.OnHoverForeColor = System.Drawing.Color.Black;
            this.HOME.OnHoverImage = null;
            this.HOME.OnPressedColor = System.Drawing.Color.Black;
            this.HOME.Radius = 8;
            this.HOME.Size = new System.Drawing.Size(127, 45);
            this.HOME.TabIndex = 2;
            this.HOME.Text = "HOME";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 735);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1240, 10);
            this.panel8.TabIndex = 51;
            // 
            // Search
            // 
            this.Search.AnimationHoverSpeed = 0.07F;
            this.Search.AnimationSpeed = 0.03F;
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.BorderColor = System.Drawing.Color.Black;
            this.Search.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Search.FocusedColor = System.Drawing.Color.Empty;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Image = ((System.Drawing.Image)(resources.GetObject("Search.Image")));
            this.Search.ImageSize = new System.Drawing.Size(20, 20);
            this.Search.Location = new System.Drawing.Point(1049, 6);
            this.Search.Name = "Search";
            this.Search.OnHoverBaseColor = System.Drawing.Color.White;
            this.Search.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Search.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.OnHoverImage = null;
            this.Search.OnPressedColor = System.Drawing.Color.Black;
            this.Search.Radius = 15;
            this.Search.Size = new System.Drawing.Size(213, 37);
            this.Search.TabIndex = 6;
            this.Search.Text = "Search Here";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.Search);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 70);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1240, 46);
            this.panel7.TabIndex = 52;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.gunaButton8);
            this.panel9.Controls.Add(this.gunaButton9);
            this.panel9.Controls.Add(this.gunaButton10);
            this.panel9.Controls.Add(this.gunaButton11);
            this.panel9.Controls.Add(this.gunaButton12);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 116);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(55, 619);
            this.panel9.TabIndex = 53;
            // 
            // gunaButton8
            // 
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton8.ForeColor = System.Drawing.Color.Black;
            this.gunaButton8.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton8.Image")));
            this.gunaButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton8.Location = new System.Drawing.Point(-19, 566);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Radius = 15;
            this.gunaButton8.Size = new System.Drawing.Size(71, 37);
            this.gunaButton8.TabIndex = 9;
            // 
            // gunaButton9
            // 
            this.gunaButton9.AnimationHoverSpeed = 0.07F;
            this.gunaButton9.AnimationSpeed = 0.03F;
            this.gunaButton9.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton9.BorderColor = System.Drawing.Color.Black;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton9.ForeColor = System.Drawing.Color.Black;
            this.gunaButton9.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton9.Image")));
            this.gunaButton9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton9.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton9.Location = new System.Drawing.Point(-19, 524);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton9.Radius = 15;
            this.gunaButton9.Size = new System.Drawing.Size(71, 37);
            this.gunaButton9.TabIndex = 8;
            // 
            // gunaButton10
            // 
            this.gunaButton10.AnimationHoverSpeed = 0.07F;
            this.gunaButton10.AnimationSpeed = 0.03F;
            this.gunaButton10.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton10.BorderColor = System.Drawing.Color.Black;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton10.ForeColor = System.Drawing.Color.Black;
            this.gunaButton10.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton10.Image")));
            this.gunaButton10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton10.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton10.Location = new System.Drawing.Point(-19, 481);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton10.Radius = 15;
            this.gunaButton10.Size = new System.Drawing.Size(71, 37);
            this.gunaButton10.TabIndex = 8;
            // 
            // gunaButton11
            // 
            this.gunaButton11.AnimationHoverSpeed = 0.07F;
            this.gunaButton11.AnimationSpeed = 0.03F;
            this.gunaButton11.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton11.BorderColor = System.Drawing.Color.Black;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton11.ForeColor = System.Drawing.Color.Black;
            this.gunaButton11.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton11.Image")));
            this.gunaButton11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton11.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton11.Location = new System.Drawing.Point(-19, 438);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton11.Radius = 15;
            this.gunaButton11.Size = new System.Drawing.Size(71, 37);
            this.gunaButton11.TabIndex = 9;
            // 
            // gunaButton12
            // 
            this.gunaButton12.AnimationHoverSpeed = 0.07F;
            this.gunaButton12.AnimationSpeed = 0.03F;
            this.gunaButton12.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton12.BorderColor = System.Drawing.Color.Black;
            this.gunaButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton12.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton12.ForeColor = System.Drawing.Color.Black;
            this.gunaButton12.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton12.Image")));
            this.gunaButton12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton12.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton12.Location = new System.Drawing.Point(-19, 395);
            this.gunaButton12.Name = "gunaButton12";
            this.gunaButton12.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton12.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverImage = null;
            this.gunaButton12.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton12.Radius = 15;
            this.gunaButton12.Size = new System.Drawing.Size(71, 37);
            this.gunaButton12.TabIndex = 7;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(61, 455);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(611, 567);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 54;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(811, 138);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(366, 41);
            this.textBox6.TabIndex = 55;
            this.textBox6.Text = "SELLER PAGE  විකුණුම් පිටුව";
            // 
            // SellPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1240, 745);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.gunaButton6);
            this.Controls.Add(this.gunaButton5);
            this.Controls.Add(this.gunaButton4);
            this.Controls.Add(this.gunaButton3);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.telephonelbl);
            this.Controls.Add(this.addresslbl);
            this.Controls.Add(this.unitlbl);
            this.Controls.Add(this.quantitylbl);
            this.Controls.Add(this.pricelbl);
            this.Controls.Add(this.categorylbl);
            this.Controls.Add(this.namelbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.telephonetb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.addresstb);
            this.Controls.Add(this.unitcb);
            this.Controls.Add(this.categorycb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quantitytb);
            this.Controls.Add(this.pricetb);
            this.Controls.Add(this.nametb);
            this.Controls.Add(this.gunaButton2);
            this.Controls.Add(this.gunaCirclePictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SellPage";
            this.Text = "SellHomePage";
            this.Load += new System.EventHandler(this.SellHomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.TextBox nametb;
        private System.Windows.Forms.TextBox pricetb;
        private System.Windows.Forms.TextBox quantitytb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox categorycb;
        private System.Windows.Forms.ComboBox unitcb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox addresstb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox telephonetb;
        private System.Windows.Forms.Label namelbl;
        private System.Windows.Forms.Label categorylbl;
        private System.Windows.Forms.Label pricelbl;
        private System.Windows.Forms.Label quantitylbl;
        private System.Windows.Forms.Label unitlbl;
        private System.Windows.Forms.Label addresslbl;
        private System.Windows.Forms.Label telephonelbl;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI.WinForms.GunaButton MORE;
        private Guna.UI.WinForms.GunaButton gunaButton7;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaButton LOGOUT;
        private System.Windows.Forms.Panel panel5;
        private Guna.UI.WinForms.GunaButton SELLPRODUCT;
        private Guna.UI.WinForms.GunaButton BUYPRODUCT;
        private Guna.UI.WinForms.GunaButton HOME;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI.WinForms.GunaButton Search;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private Guna.UI.WinForms.GunaButton gunaButton9;
        private Guna.UI.WinForms.GunaButton gunaButton10;
        private Guna.UI.WinForms.GunaButton gunaButton11;
        private Guna.UI.WinForms.GunaButton gunaButton12;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private System.Windows.Forms.TextBox textBox6;
    }
}