﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AyukarmaFinal
{
    public partial class SellerPage : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-R8SRBBL;Initial Catalog=AYU;Integrated Security=True;User ID= ;Password= ");
        String activeNIC = "456";

        public SellerPage()
        {
            InitializeComponent();
            loadForm();
            loadForm2();
            renderAdId(ucb1);
            renderAdId(dcb);
        }

        public void loadForm()
        {
            String query = "SELECT * FROM dbo.Selling WHERE NICNo = '" + activeNIC + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "Selling");
            dataGridView1.DataSource = ds.Tables["Selling"].DefaultView;
        }

        public void loadForm2()
        {
            String query = "SELECT * FROM dbo.Selling WHERE NICNo = '" + activeNIC + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "Selling");
            dataGridView2.DataSource = ds.Tables["Selling"].DefaultView;
        }

        public void renderAdId(ComboBox cb)
        {
            try
            {
                SqlCommand cmd1 = new SqlCommand("SELECT SellingID FROM dbo.Selling WHERE NICNo='" + activeNIC + "'", conn);

                SqlDataReader rdr = null;
                conn.Open();
                rdr = cmd1.ExecuteReader();

                while (rdr.Read())
                {
                    int adno = (int)rdr["SellingID"];
                    cb.Items.Add(adno);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

            private void gunaButton1_Click(object sender, EventArgs e)
            {
            int count = 0;
            if (String.IsNullOrEmpty(ucb1.Text))
            {
                setLabel(ucb1lbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(ucb2.Text))
            {
                setLabel(ucb2lbl, "Required");
            }
            else
            {
                count += 1;
            }

            if (String.IsNullOrEmpty(utb.Text))
            {
                setLabel(utblbl, "Required");
            }
            else
            {
                count += 1;
            }
            if (count == 3)
            {
                try
                {
                    var confirmResult = MessageBox.Show("Are you sure want to update the advertisement (" + Convert.ToInt32(ucb1.Text) + ") " + ucb2.Text + " to " + utb.Text + " ?",
                                        "Confirmation Message",
                                        MessageBoxButtons.YesNo);
                    if (confirmResult == DialogResult.Yes)
                    {
                        String query = "UPDATE dbo.Selling SET " + ucb2.Text + " = '" + utb.Text + "' WHERE SellingID = " + Convert.ToInt32(ucb1.Text);
                        SqlCommand cmd = new SqlCommand(query, conn);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    loadForm();
                    loadForm2();
                }
            }
               
            }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            try
            {
                var confirmResult = MessageBox.Show("Are you sure want to delete the advertisement bearing the Ad number " + Convert.ToInt32(dcb.Text) +" ?",
                                    "Confirmation Message",
                                    MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {

                    String query = "DELETE FROM dbo.Selling WHERE SellingID = " + Convert.ToInt32(dcb.Text);
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                ucb1.Items.Clear();
                dcb.Items.Clear();
                loadForm();
                loadForm2();
                renderAdId(ucb1);
                renderAdId(dcb);
            }
        }

        public void setLabel(Label mylab, String message)
        {
            // Creating and setting the label 
            mylab.Text = message;
            mylab.Font = new Font("Calibri", 8);
            mylab.ForeColor = Color.Red;
        }

        private void SellerPage_Load(object sender, EventArgs e)
        {

        }
    }
}
