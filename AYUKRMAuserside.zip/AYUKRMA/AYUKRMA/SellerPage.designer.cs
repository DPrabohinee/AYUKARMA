﻿namespace AyukarmaFinal
{
    partial class SellerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellerPage));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.utblbl = new System.Windows.Forms.Label();
            this.ucb2lbl = new System.Windows.Forms.Label();
            this.ucb1lbl = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.utb = new System.Windows.Forms.TextBox();
            this.ucb2 = new System.Windows.Forms.ComboBox();
            this.ucb1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.dcb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.MORE = new Guna.UI.WinForms.GunaButton();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LOGOUT = new Guna.UI.WinForms.GunaButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.SELLPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BUYPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.HOME = new Guna.UI.WinForms.GunaButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Search = new Guna.UI.WinForms.GunaButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(105, 174);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1073, 98);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.label1.Location = new System.Drawing.Point(99, 129);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(787, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Your Published Advertisements | ඔබේ ප්‍රකාශිත දැන්වීම් :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.utblbl);
            this.groupBox1.Controls.Add(this.ucb2lbl);
            this.groupBox1.Controls.Add(this.ucb1lbl);
            this.groupBox1.Controls.Add(this.gunaButton1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.utb);
            this.groupBox1.Controls.Add(this.ucb2);
            this.groupBox1.Controls.Add(this.ucb1);
            this.groupBox1.Location = new System.Drawing.Point(105, 308);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(419, 210);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Update | යාවත්කාලීන කරන්න :";
            // 
            // utblbl
            // 
            this.utblbl.AutoSize = true;
            this.utblbl.Location = new System.Drawing.Point(253, 112);
            this.utblbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.utblbl.Name = "utblbl";
            this.utblbl.Size = new System.Drawing.Size(0, 17);
            this.utblbl.TabIndex = 31;
            // 
            // ucb2lbl
            // 
            this.ucb2lbl.AutoSize = true;
            this.ucb2lbl.Location = new System.Drawing.Point(253, 65);
            this.ucb2lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ucb2lbl.Name = "ucb2lbl";
            this.ucb2lbl.Size = new System.Drawing.Size(0, 17);
            this.ucb2lbl.TabIndex = 30;
            // 
            // ucb1lbl
            // 
            this.ucb1lbl.AutoSize = true;
            this.ucb1lbl.Location = new System.Drawing.Point(253, 20);
            this.ucb1lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ucb1lbl.Name = "ucb1lbl";
            this.ucb1lbl.Size = new System.Drawing.Size(0, 17);
            this.ucb1lbl.TabIndex = 29;
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(97, 162);
            this.gunaButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 10;
            this.gunaButton1.Size = new System.Drawing.Size(219, 39);
            this.gunaButton1.TabIndex = 28;
            this.gunaButton1.Text = "Update";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "To | වෙත :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 89);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Change | වෙනස් කරන්න :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ad Number | දැන්වීම් අංකය :";
            // 
            // utb
            // 
            this.utb.Location = new System.Drawing.Point(257, 132);
            this.utb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.utb.Name = "utb";
            this.utb.Size = new System.Drawing.Size(133, 22);
            this.utb.TabIndex = 2;
            // 
            // ucb2
            // 
            this.ucb2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucb2.FormattingEnabled = true;
            this.ucb2.Items.AddRange(new object[] {
            "Price",
            "Quantity"});
            this.ucb2.Location = new System.Drawing.Point(257, 85);
            this.ucb2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ucb2.Name = "ucb2";
            this.ucb2.Size = new System.Drawing.Size(135, 24);
            this.ucb2.TabIndex = 1;
            // 
            // ucb1
            // 
            this.ucb1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ucb1.FormattingEnabled = true;
            this.ucb1.Location = new System.Drawing.Point(257, 39);
            this.ucb1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ucb1.Name = "ucb1";
            this.ucb1.Size = new System.Drawing.Size(135, 24);
            this.ucb1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gunaButton2);
            this.groupBox2.Controls.Add(this.dcb);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(105, 548);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(417, 124);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Remove | ඉවත් කරන්න :";
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(97, 76);
            this.gunaButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 10;
            this.gunaButton2.Size = new System.Drawing.Size(219, 39);
            this.gunaButton2.TabIndex = 29;
            this.gunaButton2.Text = "Delete";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // dcb
            // 
            this.dcb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dcb.FormattingEnabled = true;
            this.dcb.Location = new System.Drawing.Point(256, 44);
            this.dcb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dcb.Name = "dcb";
            this.dcb.Size = new System.Drawing.Size(135, 24);
            this.dcb.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 48);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 17);
            this.label5.TabIndex = 29;
            this.label5.Text = "Ad Number | දැන්වීම් අංකය :";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(560, 349);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(608, 311);
            this.dataGridView2.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.label6.Location = new System.Drawing.Point(565, 305);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(519, 37);
            this.label6.TabIndex = 5;
            this.label6.Text = "Emergency Needs | හදිසි අවශ්‍යතා :";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.gunaButton6);
            this.panel9.Controls.Add(this.gunaButton5);
            this.panel9.Controls.Add(this.gunaButton3);
            this.panel9.Controls.Add(this.gunaButton4);
            this.panel9.Controls.Add(this.gunaButton7);
            this.panel9.Location = new System.Drawing.Point(0, 129);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(68, 613);
            this.panel9.TabIndex = 19;
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.Black;
            this.gunaButton6.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton6.Image")));
            this.gunaButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(-21, 563);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Radius = 15;
            this.gunaButton6.Size = new System.Drawing.Size(71, 37);
            this.gunaButton6.TabIndex = 9;
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.Black;
            this.gunaButton5.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton5.Image")));
            this.gunaButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(-21, 521);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Radius = 15;
            this.gunaButton5.Size = new System.Drawing.Size(71, 37);
            this.gunaButton5.TabIndex = 8;
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.Black;
            this.gunaButton3.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton3.Image")));
            this.gunaButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(-21, 478);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 15;
            this.gunaButton3.Size = new System.Drawing.Size(71, 37);
            this.gunaButton3.TabIndex = 8;
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.Black;
            this.gunaButton4.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton4.Image")));
            this.gunaButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(-21, 435);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 15;
            this.gunaButton4.Size = new System.Drawing.Size(71, 37);
            this.gunaButton4.TabIndex = 9;
            // 
            // gunaButton7
            // 
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton7.ForeColor = System.Drawing.Color.Black;
            this.gunaButton7.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton7.Image")));
            this.gunaButton7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton7.Location = new System.Drawing.Point(-21, 390);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Radius = 15;
            this.gunaButton7.Size = new System.Drawing.Size(71, 39);
            this.gunaButton7.TabIndex = 7;
            // 
            // MORE
            // 
            this.MORE.AnimationHoverSpeed = 0.07F;
            this.MORE.AnimationSpeed = 0.03F;
            this.MORE.BackColor = System.Drawing.Color.Transparent;
            this.MORE.BaseColor = System.Drawing.Color.White;
            this.MORE.BorderColor = System.Drawing.Color.Black;
            this.MORE.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MORE.FocusedColor = System.Drawing.Color.Empty;
            this.MORE.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MORE.ForeColor = System.Drawing.Color.Black;
            this.MORE.Image = ((System.Drawing.Image)(resources.GetObject("MORE.Image")));
            this.MORE.ImageSize = new System.Drawing.Size(20, 20);
            this.MORE.Location = new System.Drawing.Point(923, 17);
            this.MORE.Name = "MORE";
            this.MORE.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.MORE.OnHoverBorderColor = System.Drawing.Color.Black;
            this.MORE.OnHoverForeColor = System.Drawing.Color.Black;
            this.MORE.OnHoverImage = null;
            this.MORE.OnPressedColor = System.Drawing.Color.Black;
            this.MORE.Radius = 8;
            this.MORE.Size = new System.Drawing.Size(127, 45);
            this.MORE.TabIndex = 6;
            this.MORE.Text = "MORE";
            // 
            // gunaButton8
            // 
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.White;
            this.gunaButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton8.ForeColor = System.Drawing.Color.White;
            this.gunaButton8.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton8.Image")));
            this.gunaButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton8.Location = new System.Drawing.Point(1213, 6);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Radius = 8;
            this.gunaButton8.Size = new System.Drawing.Size(24, 24);
            this.gunaButton8.TabIndex = 2;
            this.gunaButton8.Text = " ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(1056, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 45);
            this.panel6.TabIndex = 5;
            // 
            // LOGOUT
            // 
            this.LOGOUT.AnimationHoverSpeed = 0.07F;
            this.LOGOUT.AnimationSpeed = 0.03F;
            this.LOGOUT.BackColor = System.Drawing.Color.Transparent;
            this.LOGOUT.BaseColor = System.Drawing.Color.White;
            this.LOGOUT.BorderColor = System.Drawing.Color.Black;
            this.LOGOUT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.LOGOUT.FocusedColor = System.Drawing.Color.Empty;
            this.LOGOUT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGOUT.ForeColor = System.Drawing.Color.Black;
            this.LOGOUT.Image = ((System.Drawing.Image)(resources.GetObject("LOGOUT.Image")));
            this.LOGOUT.ImageSize = new System.Drawing.Size(20, 20);
            this.LOGOUT.Location = new System.Drawing.Point(1065, 17);
            this.LOGOUT.Name = "LOGOUT";
            this.LOGOUT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.LOGOUT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverForeColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverImage = null;
            this.LOGOUT.OnPressedColor = System.Drawing.Color.Black;
            this.LOGOUT.Radius = 8;
            this.LOGOUT.Size = new System.Drawing.Size(142, 45);
            this.LOGOUT.TabIndex = 6;
            this.LOGOUT.Text = "LOGOUT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(914, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 45);
            this.panel5.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(704, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 45);
            this.panel4.TabIndex = 5;
            // 
            // SELLPRODUCT
            // 
            this.SELLPRODUCT.AnimationHoverSpeed = 0.07F;
            this.SELLPRODUCT.AnimationSpeed = 0.03F;
            this.SELLPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.SELLPRODUCT.BaseColor = System.Drawing.Color.White;
            this.SELLPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SELLPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.SELLPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SELLPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("SELLPRODUCT.Image")));
            this.SELLPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.SELLPRODUCT.Location = new System.Drawing.Point(713, 19);
            this.SELLPRODUCT.Name = "SELLPRODUCT";
            this.SELLPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.SELLPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverImage = null;
            this.SELLPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Radius = 8;
            this.SELLPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.SELLPRODUCT.TabIndex = 6;
            this.SELLPRODUCT.Text = "SELL PRODUCT";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(494, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 45);
            this.panel3.TabIndex = 3;
            // 
            // BUYPRODUCT
            // 
            this.BUYPRODUCT.AnimationHoverSpeed = 0.07F;
            this.BUYPRODUCT.AnimationSpeed = 0.03F;
            this.BUYPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.BUYPRODUCT.BaseColor = System.Drawing.Color.White;
            this.BUYPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BUYPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.BUYPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUYPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("BUYPRODUCT.Image")));
            this.BUYPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.BUYPRODUCT.Location = new System.Drawing.Point(503, 17);
            this.BUYPRODUCT.Name = "BUYPRODUCT";
            this.BUYPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.BUYPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverImage = null;
            this.BUYPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Radius = 8;
            this.BUYPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.BUYPRODUCT.TabIndex = 4;
            this.BUYPRODUCT.Text = "BUY PRODUCT";
            // 
            // HOME
            // 
            this.HOME.AnimationHoverSpeed = 0.07F;
            this.HOME.AnimationSpeed = 0.03F;
            this.HOME.BackColor = System.Drawing.Color.Transparent;
            this.HOME.BaseColor = System.Drawing.Color.White;
            this.HOME.BorderColor = System.Drawing.Color.Black;
            this.HOME.DialogResult = System.Windows.Forms.DialogResult.None;
            this.HOME.FocusedColor = System.Drawing.Color.Empty;
            this.HOME.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HOME.ForeColor = System.Drawing.Color.Black;
            this.HOME.Image = ((System.Drawing.Image)(resources.GetObject("HOME.Image")));
            this.HOME.ImageSize = new System.Drawing.Size(20, 20);
            this.HOME.Location = new System.Drawing.Point(361, 19);
            this.HOME.Name = "HOME";
            this.HOME.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.HOME.OnHoverBorderColor = System.Drawing.Color.Black;
            this.HOME.OnHoverForeColor = System.Drawing.Color.Black;
            this.HOME.OnHoverImage = null;
            this.HOME.OnPressedColor = System.Drawing.Color.Black;
            this.HOME.Radius = 8;
            this.HOME.Size = new System.Drawing.Size(127, 45);
            this.HOME.TabIndex = 2;
            this.HOME.Text = "HOME";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(88, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(156, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.Search);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 80);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1240, 46);
            this.panel7.TabIndex = 22;
            // 
            // Search
            // 
            this.Search.AnimationHoverSpeed = 0.07F;
            this.Search.AnimationSpeed = 0.03F;
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.BorderColor = System.Drawing.Color.Black;
            this.Search.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Search.FocusedColor = System.Drawing.Color.Empty;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Image = ((System.Drawing.Image)(resources.GetObject("Search.Image")));
            this.Search.ImageSize = new System.Drawing.Size(20, 20);
            this.Search.Location = new System.Drawing.Point(1065, 6);
            this.Search.Name = "Search";
            this.Search.OnHoverBaseColor = System.Drawing.Color.White;
            this.Search.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Search.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.OnHoverImage = null;
            this.Search.OnPressedColor = System.Drawing.Color.Black;
            this.Search.Radius = 15;
            this.Search.Size = new System.Drawing.Size(208, 37);
            this.Search.TabIndex = 6;
            this.Search.Text = "Search Here";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1240, 10);
            this.panel1.TabIndex = 20;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.MORE);
            this.panel2.Controls.Add(this.gunaButton8);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.LOGOUT);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.SELLPRODUCT);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.BUYPRODUCT);
            this.panel2.Controls.Add(this.HOME);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1240, 70);
            this.panel2.TabIndex = 21;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 735);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1240, 10);
            this.panel8.TabIndex = 23;
            // 
            // SellerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1240, 745);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SellerPage";
            this.Text = "SellerPage";
            this.Load += new System.EventHandler(this.SellerPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox utb;
        private System.Windows.Forms.ComboBox ucb2;
        private System.Windows.Forms.ComboBox ucb1;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.ComboBox dcb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label utblbl;
        private System.Windows.Forms.Label ucb2lbl;
        private System.Windows.Forms.Label ucb1lbl;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton gunaButton7;
        private Guna.UI.WinForms.GunaButton MORE;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaButton LOGOUT;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private Guna.UI.WinForms.GunaButton SELLPRODUCT;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI.WinForms.GunaButton BUYPRODUCT;
        private Guna.UI.WinForms.GunaButton HOME;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI.WinForms.GunaButton Search;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
    }
}