﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYUKRMA
{
    public partial class SpecialOrder : Form
    {
        // loginwindow පේජ් එකෙන් user ID එක අරගෙන ඒ user Id එකත් එක්ක specialorder ටේබල් එකට ඩේටා ටික ඇඩ් වෙන්න ඕනේ.
        function fn = new function();
        String query;

        public SpecialOrder(int id)
        {
            InitializeComponent();
            this.userID = id;
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(" ");
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://touch.facebook.com/"); 
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/accounts/login/");
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/login?lang=en-gb");
        }

        private void gunaButton6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(" ");
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            {
                query = "insert into SpecialOrders (ProductName,UserID,Quantity,DeadLine) values ('" + gunaTextBox1.Text + "','" + userID + "','" + txtQuantity.Text + "','" + gunaDateTimePicker1.Text + "')";
                fn.setData(query);
                clearAll();
            }
        }

        public void clearAll()
        {
            gunaTextBox1.Clear();
            txtQuantity.Clear();
            gunaTextBox2.Clear();
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
