﻿
namespace AYUKRMA
{
    partial class SpecialOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpecialOrder));
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.MORE = new Guna.UI.WinForms.GunaButton();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.LOGOUT = new Guna.UI.WinForms.GunaButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.SELLPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BUYPRODUCT = new Guna.UI.WinForms.GunaButton();
            this.HOME = new Guna.UI.WinForms.GunaButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Search = new Guna.UI.WinForms.GunaButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.gunaDateTimePicker1 = new Guna.UI.WinForms.GunaDateTimePicker();
            this.gunaTextBox2 = new Guna.UI.WinForms.GunaTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gunaTextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.btnAddOrder = new Guna.UI.WinForms.GunaButton();
            this.txtQuantity = new Guna.UI.WinForms.GunaTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.Black;
            this.gunaButton6.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton6.Image")));
            this.gunaButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(-19, 566);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Radius = 15;
            this.gunaButton6.Size = new System.Drawing.Size(71, 37);
            this.gunaButton6.TabIndex = 9;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.Black;
            this.gunaButton3.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton3.Image")));
            this.gunaButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(-19, 481);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 15;
            this.gunaButton3.Size = new System.Drawing.Size(71, 37);
            this.gunaButton3.TabIndex = 8;
            this.gunaButton3.Click += new System.EventHandler(this.gunaButton3_Click);
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.Black;
            this.gunaButton4.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton4.Image")));
            this.gunaButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(-19, 438);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 15;
            this.gunaButton4.Size = new System.Drawing.Size(71, 37);
            this.gunaButton4.TabIndex = 9;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // MORE
            // 
            this.MORE.AnimationHoverSpeed = 0.07F;
            this.MORE.AnimationSpeed = 0.03F;
            this.MORE.BackColor = System.Drawing.Color.Transparent;
            this.MORE.BaseColor = System.Drawing.Color.White;
            this.MORE.BorderColor = System.Drawing.Color.Black;
            this.MORE.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MORE.FocusedColor = System.Drawing.Color.Empty;
            this.MORE.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MORE.ForeColor = System.Drawing.Color.Black;
            this.MORE.Image = ((System.Drawing.Image)(resources.GetObject("MORE.Image")));
            this.MORE.ImageSize = new System.Drawing.Size(20, 20);
            this.MORE.Location = new System.Drawing.Point(923, 17);
            this.MORE.Name = "MORE";
            this.MORE.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.MORE.OnHoverBorderColor = System.Drawing.Color.Black;
            this.MORE.OnHoverForeColor = System.Drawing.Color.Black;
            this.MORE.OnHoverImage = null;
            this.MORE.OnPressedColor = System.Drawing.Color.Black;
            this.MORE.Radius = 8;
            this.MORE.Size = new System.Drawing.Size(127, 45);
            this.MORE.TabIndex = 6;
            this.MORE.Text = "MORE";
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.White;
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton1.Image")));
            this.gunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(1213, 6);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 8;
            this.gunaButton1.Size = new System.Drawing.Size(24, 24);
            this.gunaButton1.TabIndex = 2;
            this.gunaButton1.Text = " ";
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(1056, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 45);
            this.panel6.TabIndex = 5;
            // 
            // LOGOUT
            // 
            this.LOGOUT.AnimationHoverSpeed = 0.07F;
            this.LOGOUT.AnimationSpeed = 0.03F;
            this.LOGOUT.BackColor = System.Drawing.Color.Transparent;
            this.LOGOUT.BaseColor = System.Drawing.Color.White;
            this.LOGOUT.BorderColor = System.Drawing.Color.Black;
            this.LOGOUT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.LOGOUT.FocusedColor = System.Drawing.Color.Empty;
            this.LOGOUT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGOUT.ForeColor = System.Drawing.Color.Black;
            this.LOGOUT.Image = ((System.Drawing.Image)(resources.GetObject("LOGOUT.Image")));
            this.LOGOUT.ImageSize = new System.Drawing.Size(20, 20);
            this.LOGOUT.Location = new System.Drawing.Point(1065, 17);
            this.LOGOUT.Name = "LOGOUT";
            this.LOGOUT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.LOGOUT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverForeColor = System.Drawing.Color.Black;
            this.LOGOUT.OnHoverImage = null;
            this.LOGOUT.OnPressedColor = System.Drawing.Color.Black;
            this.LOGOUT.Radius = 8;
            this.LOGOUT.Size = new System.Drawing.Size(142, 45);
            this.LOGOUT.TabIndex = 6;
            this.LOGOUT.Text = "LOGOUT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(914, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 45);
            this.panel5.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(704, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 45);
            this.panel4.TabIndex = 5;
            // 
            // SELLPRODUCT
            // 
            this.SELLPRODUCT.AnimationHoverSpeed = 0.07F;
            this.SELLPRODUCT.AnimationSpeed = 0.03F;
            this.SELLPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.SELLPRODUCT.BaseColor = System.Drawing.Color.White;
            this.SELLPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SELLPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.SELLPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SELLPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("SELLPRODUCT.Image")));
            this.SELLPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.SELLPRODUCT.Location = new System.Drawing.Point(713, 19);
            this.SELLPRODUCT.Name = "SELLPRODUCT";
            this.SELLPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.SELLPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.OnHoverImage = null;
            this.SELLPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.SELLPRODUCT.Radius = 8;
            this.SELLPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.SELLPRODUCT.TabIndex = 6;
            this.SELLPRODUCT.Text = "SELL PRODUCT";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(494, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 45);
            this.panel3.TabIndex = 3;
            // 
            // BUYPRODUCT
            // 
            this.BUYPRODUCT.AnimationHoverSpeed = 0.07F;
            this.BUYPRODUCT.AnimationSpeed = 0.03F;
            this.BUYPRODUCT.BackColor = System.Drawing.Color.Transparent;
            this.BUYPRODUCT.BaseColor = System.Drawing.Color.White;
            this.BUYPRODUCT.BorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BUYPRODUCT.FocusedColor = System.Drawing.Color.Empty;
            this.BUYPRODUCT.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUYPRODUCT.ForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Image = ((System.Drawing.Image)(resources.GetObject("BUYPRODUCT.Image")));
            this.BUYPRODUCT.ImageSize = new System.Drawing.Size(20, 20);
            this.BUYPRODUCT.Location = new System.Drawing.Point(503, 17);
            this.BUYPRODUCT.Name = "BUYPRODUCT";
            this.BUYPRODUCT.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.BUYPRODUCT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverForeColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.OnHoverImage = null;
            this.BUYPRODUCT.OnPressedColor = System.Drawing.Color.Black;
            this.BUYPRODUCT.Radius = 8;
            this.BUYPRODUCT.Size = new System.Drawing.Size(195, 45);
            this.BUYPRODUCT.TabIndex = 4;
            this.BUYPRODUCT.Text = "BUY PRODUCT";
            // 
            // HOME
            // 
            this.HOME.AnimationHoverSpeed = 0.07F;
            this.HOME.AnimationSpeed = 0.03F;
            this.HOME.BackColor = System.Drawing.Color.Transparent;
            this.HOME.BaseColor = System.Drawing.Color.White;
            this.HOME.BorderColor = System.Drawing.Color.Black;
            this.HOME.DialogResult = System.Windows.Forms.DialogResult.None;
            this.HOME.FocusedColor = System.Drawing.Color.Empty;
            this.HOME.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HOME.ForeColor = System.Drawing.Color.Black;
            this.HOME.Image = ((System.Drawing.Image)(resources.GetObject("HOME.Image")));
            this.HOME.ImageSize = new System.Drawing.Size(20, 20);
            this.HOME.Location = new System.Drawing.Point(361, 19);
            this.HOME.Name = "HOME";
            this.HOME.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.HOME.OnHoverBorderColor = System.Drawing.Color.Black;
            this.HOME.OnHoverForeColor = System.Drawing.Color.Black;
            this.HOME.OnHoverImage = null;
            this.HOME.OnPressedColor = System.Drawing.Color.Black;
            this.HOME.Radius = 8;
            this.HOME.Size = new System.Drawing.Size(127, 45);
            this.HOME.TabIndex = 2;
            this.HOME.Text = "HOME";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(1220, 126);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(20, 609);
            this.panel10.TabIndex = 12;
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.Black;
            this.gunaButton2.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton2.Image")));
            this.gunaButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(-19, 395);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 15;
            this.gunaButton2.Size = new System.Drawing.Size(71, 37);
            this.gunaButton2.TabIndex = 7;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.gunaButton6);
            this.panel9.Controls.Add(this.gunaButton5);
            this.panel9.Controls.Add(this.gunaButton3);
            this.panel9.Controls.Add(this.gunaButton4);
            this.panel9.Controls.Add(this.gunaButton2);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 126);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(55, 609);
            this.panel9.TabIndex = 11;
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.Black;
            this.gunaButton5.Image = ((System.Drawing.Image)(resources.GetObject("gunaButton5.Image")));
            this.gunaButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(-19, 524);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Radius = 15;
            this.gunaButton5.Size = new System.Drawing.Size(71, 37);
            this.gunaButton5.TabIndex = 8;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(88, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(156, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // Search
            // 
            this.Search.AnimationHoverSpeed = 0.07F;
            this.Search.AnimationSpeed = 0.03F;
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.BorderColor = System.Drawing.Color.Black;
            this.Search.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Search.FocusedColor = System.Drawing.Color.Empty;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.White;
            this.Search.Image = ((System.Drawing.Image)(resources.GetObject("Search.Image")));
            this.Search.ImageSize = new System.Drawing.Size(20, 20);
            this.Search.Location = new System.Drawing.Point(1049, 6);
            this.Search.Name = "Search";
            this.Search.OnHoverBaseColor = System.Drawing.Color.White;
            this.Search.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Search.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.Search.OnHoverImage = null;
            this.Search.OnPressedColor = System.Drawing.Color.Black;
            this.Search.Radius = 15;
            this.Search.Size = new System.Drawing.Size(208, 37);
            this.Search.TabIndex = 6;
            this.Search.Text = "Search Here";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.Search);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 80);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1240, 46);
            this.panel7.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(98, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(449, 34);
            this.label5.TabIndex = 26;
            this.label5.Text = "SPECIAL ORDERS  විශේෂ ඇනවුම්";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.gunaDateTimePicker1);
            this.panel11.Controls.Add(this.label5);
            this.panel11.Controls.Add(this.gunaTextBox2);
            this.panel11.Controls.Add(this.label1);
            this.panel11.Controls.Add(this.gunaTextBox1);
            this.panel11.Controls.Add(this.btnAddOrder);
            this.panel11.Controls.Add(this.txtQuantity);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Controls.Add(this.label2);
            this.panel11.Controls.Add(this.gunaCirclePictureBox1);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 80);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1240, 655);
            this.panel11.TabIndex = 13;
            // 
            // gunaDateTimePicker1
            // 
            this.gunaDateTimePicker1.BaseColor = System.Drawing.Color.White;
            this.gunaDateTimePicker1.BorderColor = System.Drawing.Color.Silver;
            this.gunaDateTimePicker1.CustomFormat = null;
            this.gunaDateTimePicker1.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.gunaDateTimePicker1.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaDateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaDateTimePicker1.ForeColor = System.Drawing.Color.Black;
            this.gunaDateTimePicker1.Location = new System.Drawing.Point(494, 373);
            this.gunaDateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gunaDateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.gunaDateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.gunaDateTimePicker1.Name = "gunaDateTimePicker1";
            this.gunaDateTimePicker1.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaDateTimePicker1.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaDateTimePicker1.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaDateTimePicker1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaDateTimePicker1.Size = new System.Drawing.Size(548, 40);
            this.gunaDateTimePicker1.TabIndex = 29;
            this.gunaDateTimePicker1.Text = "Wednesday, March 31, 2021";
            this.gunaDateTimePicker1.Value = new System.DateTime(2021, 3, 31, 9, 44, 38, 813);
            // 
            // gunaTextBox2
            // 
            this.gunaTextBox2.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox2.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox2.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox2.Location = new System.Drawing.Point(494, 153);
            this.gunaTextBox2.Name = "gunaTextBox2";
            this.gunaTextBox2.PasswordChar = '\0';
            this.gunaTextBox2.SelectedText = "";
            this.gunaTextBox2.Size = new System.Drawing.Size(548, 34);
            this.gunaTextBox2.TabIndex = 28;
            this.gunaTextBox2.TextChanged += new System.EventHandler(this.gunaTextBox2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 25);
            this.label1.TabIndex = 27;
            this.label1.Text = "User ID";
            // 
            // gunaTextBox1
            // 
            this.gunaTextBox1.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox1.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox1.Location = new System.Drawing.Point(494, 219);
            this.gunaTextBox1.Name = "gunaTextBox1";
            this.gunaTextBox1.PasswordChar = '\0';
            this.gunaTextBox1.SelectedText = "";
            this.gunaTextBox1.Size = new System.Drawing.Size(548, 34);
            this.gunaTextBox1.TabIndex = 25;
            this.gunaTextBox1.TextChanged += new System.EventHandler(this.gunaTextBox1_TextChanged);
            // 
            // btnAddOrder
            // 
            this.btnAddOrder.AnimationHoverSpeed = 0.07F;
            this.btnAddOrder.AnimationSpeed = 0.03F;
            this.btnAddOrder.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.btnAddOrder.BorderColor = System.Drawing.Color.Black;
            this.btnAddOrder.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAddOrder.FocusedColor = System.Drawing.Color.Empty;
            this.btnAddOrder.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddOrder.ForeColor = System.Drawing.Color.White;
            this.btnAddOrder.Image = null;
            this.btnAddOrder.ImageSize = new System.Drawing.Size(20, 20);
            this.btnAddOrder.Location = new System.Drawing.Point(503, 494);
            this.btnAddOrder.Name = "btnAddOrder";
            this.btnAddOrder.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.btnAddOrder.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnAddOrder.OnHoverForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddOrder.OnHoverImage = null;
            this.btnAddOrder.OnPressedColor = System.Drawing.Color.Black;
            this.btnAddOrder.Size = new System.Drawing.Size(142, 42);
            this.btnAddOrder.TabIndex = 24;
            this.btnAddOrder.Text = "Add Order";
            this.btnAddOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddOrder.Click += new System.EventHandler(this.btnAddOrder_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.BaseColor = System.Drawing.Color.White;
            this.txtQuantity.BorderColor = System.Drawing.Color.Silver;
            this.txtQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.FocusedBaseColor = System.Drawing.Color.White;
            this.txtQuantity.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtQuantity.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtQuantity.Location = new System.Drawing.Point(494, 299);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.PasswordChar = '\0';
            this.txtQuantity.SelectedText = "";
            this.txtQuantity.Size = new System.Drawing.Size(548, 34);
            this.txtQuantity.TabIndex = 23;
            this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(261, 382);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 25);
            this.label4.TabIndex = 22;
            this.label4.Text = "Deadline";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(261, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 25);
            this.label3.TabIndex = 21;
            this.label3.Text = "Product Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(261, 308);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 25);
            this.label2.TabIndex = 20;
            this.label2.Text = "Quantity";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 735);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1240, 10);
            this.panel8.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.MORE);
            this.panel2.Controls.Add(this.gunaButton1);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.LOGOUT);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.SELLPRODUCT);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.BUYPRODUCT);
            this.panel2.Controls.Add(this.HOME);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1240, 70);
            this.panel2.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1240, 10);
            this.panel1.TabIndex = 7;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(845, 228);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(491, 457);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 30;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // SpecialOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1240, 745);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SpecialOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Template";
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton MORE;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI.WinForms.GunaButton LOGOUT;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private Guna.UI.WinForms.GunaButton SELLPRODUCT;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI.WinForms.GunaButton BUYPRODUCT;
        private Guna.UI.WinForms.GunaButton HOME;
        private System.Windows.Forms.Panel panel10;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Guna.UI.WinForms.GunaButton Search;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaDateTimePicker gunaDateTimePicker1;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox1;
        private Guna.UI.WinForms.GunaButton btnAddOrder;
        private Guna.UI.WinForms.GunaTextBox txtQuantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
    }
}