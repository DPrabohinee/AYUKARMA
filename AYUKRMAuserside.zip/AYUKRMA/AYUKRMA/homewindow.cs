﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AYUKRMA
{
    public partial class homewindow : Form
    {
        public homewindow()
        {
            InitializeComponent();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://localhost/ayukarma/pages/index.php ");
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://touch.facebook.com/");
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/accounts/login/");
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/login?lang=en-gb");
        }

        private void gunaButton6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(" ");
        }

        private void gunaButton7_Click(object sender, EventArgs e)
        {
            Buyproductwindow openForm = new Buyproductwindow();
            openForm.Show();
            Visible = false;
        }

        private void gunaButton9_Click(object sender, EventArgs e)
        {
            Orderwindow openForm = new Orderwindow();
            openForm.Show();
            Visible = false;
        }

        private void gunaButton10_Click(object sender, EventArgs e)
        {
            //email page 
        }

        private void gunaButton11_Click(object sender, EventArgs e)
        {
            //add Doctors and centers link
        }

        private void gunaButton12_Click(object sender, EventArgs e)
        {
            //add knowladge panel link
        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void HOME_Click(object sender, EventArgs e)
        {
            homewindow openForm = new homewindow();
            openForm.Show();
            Visible = false;
        }

        private void BUYPRODUCT_Click(object sender, EventArgs e)
        {
            Buyproductwindow openForm = new Buyproductwindow();
            openForm.Show();
            Visible = false;
        }

        private void SELLPRODUCT_Click(object sender, EventArgs e)
        {
            Buyproductwindow openForm = new Buyproductwindow();
            openForm.Show();
            Visible = false;
        }

    }
    }
}
