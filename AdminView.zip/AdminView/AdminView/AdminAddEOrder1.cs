﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminAddEOrder1 : Form
    {
        Message msg = new Message();
        SQLClass sql = new SQLClass();

        SqlConnection con = new SqlConnection(@"");

        public AdminAddEOrder1()
        {
            InitializeComponent();
            loadData();
        }

        #region Color Customize Section
        private void butHover(Button but)
        {
            but.BackColor = Color.FromArgb(100, 88, 255);
            but.ForeColor = Color.White;
        }

        private void butUnHover(Button but)
        {
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            butHover(button1);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            butUnHover(button1);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            butHover(button2);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            butUnHover(button2);
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            butHover(button3);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            butUnHover(button3);
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            if (txt.Text == "Click here to add Order ID")
            {
                txt.Text = "";
                txt.ForeColor = Color.Black;
                clear();
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (txt.Text == "")
            {
                txt.Text = "Click here to add Order ID";
                txt.ForeColor = Color.Gray;
            }
        }
        #endregion

        private void clear()
        {
            lab.Text = null;
        }

        #region Load Data Section
        private void loadData()
        {
            string table = "";
            string que = "";

            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                dataView.DataSource = ds;
                dataView.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                msg.invalid_data(s1);
            }
            finally
            {
                con.Close();
            }
        }

        #endregion

        private void button2_Click(object sender, EventArgs e)
        {
            if(txt.Text == "Click here to add Order ID")
            {
                lab.Text = "* Enter a Order ID";
            }
            else { clear(); }
        }
    }
}
