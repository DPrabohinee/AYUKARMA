﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminAddUser : Form
    {
        private Form activeForm = null;
        private int i = 0, j = 0;

        public AdminAddUser()
        {
            InitializeComponent();
            clickUser();
        }

        #region Panel Customize Section
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        #endregion

        #region Color Customize Section
        private void butColorNull()
        {
            Panel[] pan1 = { panelUser, panelPendingUser, panelEmail };
            Button[] but1 = { butUser, butPendingUser, butEmail };
            for (i = 0; i < pan1.Length; ++i)
            {
                pan1[i].BackColor = Color.Gray;
                but1[i].BackColor = Color.White;
            }
        }

        private void butColor(Button but)
        {
            butColorNull();
            Panel[] pan1 = { panelUser, panelPendingUser, panelEmail };
            Button[] but1 = { butUser, butPendingUser, butEmail };
            for (i = 0; i < but1.Length; ++i)
            {
                if (but == but1[i])
                {
                    //pan1[i].BackColor = Color.FromArgb(100, 88, 255);
                    pan1[i].BackColor = Color.White;
                }
            }
        }
        #endregion

        #region Function Section
        private void closeForm()
        {
            if (activeForm != null)
            { activeForm.Close(); }
        }

        private void clickPendingUser()
        {
            butColor(butPendingUser);
            closeForm();
        }

        private void clickEmail()
        {
            butColor(butEmail);
            openFroms(new AdminSentEmail());
        }

        private void clickUser()
        {
            butColor(butUser);
            closeForm();
        }
        #endregion

        private void butPendingUser_Click(object sender, EventArgs e)
        {
            clickPendingUser();
        }

        private void butEmail_Click(object sender, EventArgs e)
        {
            clickEmail();
        }

        private void butUser_Click(object sender, EventArgs e)
        {
            clickUser();
        }
    }
}
