﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.InteropServices;

namespace AdminView
{
    public partial class AdminChangePassword : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();
        EncryptClass ent = new EncryptClass();

        private string nic = null;

        public AdminChangePassword(string nic)
        {
            InitializeComponent();
            this.Text = String.Empty;
            this.ControlBox = false;
            clearFields();
            this.nic = nic;
        }

        #region Control Box Settings
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        #endregion

        #region Function Section
        private void clear()
        {
            warning1.Text = null;
            warning2.Text = null;
        }

        private void clearFields()
        {
            currentPWord.Text = null;
            newPWord1.Text = null;
            newPWord2.Text = null;
            clear();
        }

        private void changePassword()
        {
            clear();

            string cp = currentPWord.Text;
            string np1 = newPWord1.Text;
            string np2 = newPWord2.Text;

            if(cp == null || cp == "")
            {
                warning1.Text = "* please enter your password";
            }
            else
            {
                if(np1 == null || np2 == "")
                {
                    warning2.Text = "* please enter a new password";
                }
                else
                {
                    if(np2 == null || np2 == "")
                    {
                        warning2.Text = "* please conform new password";
                    }
                    else
                    {
                        if(ent.Decrypt(sql.checkAdminPassword(nic),nic) != cp)
                        {
                            warning1.Text = "* Invalid Password";
                        }
                        else
                        {
                            if(np1 != np2)
                            {
                                warning2.Text = "* new passwords dosn't match";
                            }
                            else
                            {
                                int t = sql.updateAdminPasswords(nic, ent.Encrypt(np1,nic));
                                if(t == 0)
                                {
                                    msg.invalid_changePassword();
                                }
                                else if(t == 1)
                                {
                                    clearFields();
                                    msg.succes_changePassword();
                                    this.Close();
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            changePassword();
        }
    }
}
