﻿
namespace AdminView
{
    partial class AdminDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.typeShow = new System.Windows.Forms.Label();
            this.dataGrid = new Guna.UI.WinForms.GunaDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelUserData = new System.Windows.Forms.Panel();
            this.user4 = new System.Windows.Forms.Button();
            this.user3 = new System.Windows.Forms.Button();
            this.user2 = new System.Windows.Forms.Button();
            this.user1 = new System.Windows.Forms.Button();
            this.panelBuySellData = new System.Windows.Forms.Panel();
            this.panelRawSub = new System.Windows.Forms.Panel();
            this.raw6 = new System.Windows.Forms.Button();
            this.raw5 = new System.Windows.Forms.Button();
            this.raw4 = new System.Windows.Forms.Button();
            this.raw3 = new System.Windows.Forms.Button();
            this.raw2 = new System.Windows.Forms.Button();
            this.raw1 = new System.Windows.Forms.Button();
            this.panelRawMain = new System.Windows.Forms.Panel();
            this.butRaw = new System.Windows.Forms.Button();
            this.panelProdSub = new System.Windows.Forms.Panel();
            this.prod6 = new System.Windows.Forms.Button();
            this.prod5 = new System.Windows.Forms.Button();
            this.prod4 = new System.Windows.Forms.Button();
            this.prod3 = new System.Windows.Forms.Button();
            this.prod2 = new System.Windows.Forms.Button();
            this.prod1 = new System.Windows.Forms.Button();
            this.panelProdMain = new System.Windows.Forms.Panel();
            this.butProd = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelAllData = new System.Windows.Forms.Panel();
            this.butAllData = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelUserData.SuspendLayout();
            this.panelBuySellData.SuspendLayout();
            this.panelRawSub.SuspendLayout();
            this.panelRawMain.SuspendLayout();
            this.panelProdSub.SuspendLayout();
            this.panelProdMain.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelAllData.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(60, 12);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(10, 725);
            this.gunaVSeparator1.TabIndex = 1;
            // 
            // typeShow
            // 
            this.typeShow.AutoSize = true;
            this.typeShow.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeShow.Location = new System.Drawing.Point(76, 22);
            this.typeShow.Name = "typeShow";
            this.typeShow.Size = new System.Drawing.Size(130, 28);
            this.typeShow.TabIndex = 2;
            this.typeShow.Text = "Type Data";
            // 
            // dataGrid
            // 
            this.dataGrid.AllowUserToAddRows = false;
            this.dataGrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid.BackgroundColor = System.Drawing.Color.White;
            this.dataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGrid.ColumnHeadersHeight = 21;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGrid.EnableHeadersVisualStyles = false;
            this.dataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGrid.Location = new System.Drawing.Point(76, 70);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.ReadOnly = true;
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGrid.Size = new System.Drawing.Size(758, 667);
            this.dataGrid.TabIndex = 3;
            this.dataGrid.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.dataGrid.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGrid.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dataGrid.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dataGrid.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dataGrid.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dataGrid.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dataGrid.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGrid.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dataGrid.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGrid.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dataGrid.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGrid.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dataGrid.ThemeStyle.HeaderStyle.Height = 21;
            this.dataGrid.ThemeStyle.ReadOnly = true;
            this.dataGrid.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGrid.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGrid.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dataGrid.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataGrid.ThemeStyle.RowsStyle.Height = 22;
            this.dataGrid.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGrid.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(109)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.panelUserData);
            this.panel1.Controls.Add(this.panelBuySellData);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(857, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(211, 749);
            this.panel1.TabIndex = 4;
            // 
            // panelUserData
            // 
            this.panelUserData.Controls.Add(this.user4);
            this.panelUserData.Controls.Add(this.user3);
            this.panelUserData.Controls.Add(this.user2);
            this.panelUserData.Controls.Add(this.user1);
            this.panelUserData.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUserData.Location = new System.Drawing.Point(0, 778);
            this.panelUserData.Name = "panelUserData";
            this.panelUserData.Size = new System.Drawing.Size(194, 189);
            this.panelUserData.TabIndex = 4;
            // 
            // user4
            // 
            this.user4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(109)))), ((int)(((byte)(192)))));
            this.user4.Dock = System.Windows.Forms.DockStyle.Top;
            this.user4.FlatAppearance.BorderSize = 0;
            this.user4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user4.ForeColor = System.Drawing.Color.White;
            this.user4.Location = new System.Drawing.Point(0, 135);
            this.user4.Name = "user4";
            this.user4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.user4.Size = new System.Drawing.Size(194, 45);
            this.user4.TabIndex = 3;
            this.user4.Text = "Black List";
            this.user4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user4.UseVisualStyleBackColor = false;
            // 
            // user3
            // 
            this.user3.Dock = System.Windows.Forms.DockStyle.Top;
            this.user3.FlatAppearance.BorderSize = 0;
            this.user3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user3.ForeColor = System.Drawing.Color.White;
            this.user3.Location = new System.Drawing.Point(0, 90);
            this.user3.Name = "user3";
            this.user3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.user3.Size = new System.Drawing.Size(194, 45);
            this.user3.TabIndex = 2;
            this.user3.Text = "Seller";
            this.user3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user3.UseVisualStyleBackColor = true;
            // 
            // user2
            // 
            this.user2.Dock = System.Windows.Forms.DockStyle.Top;
            this.user2.FlatAppearance.BorderSize = 0;
            this.user2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user2.ForeColor = System.Drawing.Color.White;
            this.user2.Location = new System.Drawing.Point(0, 45);
            this.user2.Name = "user2";
            this.user2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.user2.Size = new System.Drawing.Size(194, 45);
            this.user2.TabIndex = 1;
            this.user2.Text = "Buyer";
            this.user2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user2.UseVisualStyleBackColor = true;
            // 
            // user1
            // 
            this.user1.Dock = System.Windows.Forms.DockStyle.Top;
            this.user1.FlatAppearance.BorderSize = 0;
            this.user1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.user1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user1.ForeColor = System.Drawing.Color.White;
            this.user1.Location = new System.Drawing.Point(0, 0);
            this.user1.Name = "user1";
            this.user1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.user1.Size = new System.Drawing.Size(194, 45);
            this.user1.TabIndex = 0;
            this.user1.Text = "Buyer and Seller";
            this.user1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user1.UseVisualStyleBackColor = true;
            // 
            // panelBuySellData
            // 
            this.panelBuySellData.Controls.Add(this.panelRawSub);
            this.panelBuySellData.Controls.Add(this.panelRawMain);
            this.panelBuySellData.Controls.Add(this.panelProdSub);
            this.panelBuySellData.Controls.Add(this.panelProdMain);
            this.panelBuySellData.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBuySellData.Location = new System.Drawing.Point(0, 147);
            this.panelBuySellData.Name = "panelBuySellData";
            this.panelBuySellData.Size = new System.Drawing.Size(194, 631);
            this.panelBuySellData.TabIndex = 2;
            // 
            // panelRawSub
            // 
            this.panelRawSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(77)))), ((int)(((byte)(133)))));
            this.panelRawSub.Controls.Add(this.raw6);
            this.panelRawSub.Controls.Add(this.raw5);
            this.panelRawSub.Controls.Add(this.raw4);
            this.panelRawSub.Controls.Add(this.raw3);
            this.panelRawSub.Controls.Add(this.raw2);
            this.panelRawSub.Controls.Add(this.raw1);
            this.panelRawSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelRawSub.Location = new System.Drawing.Point(0, 363);
            this.panelRawSub.Name = "panelRawSub";
            this.panelRawSub.Size = new System.Drawing.Size(194, 266);
            this.panelRawSub.TabIndex = 4;
            // 
            // raw6
            // 
            this.raw6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(77)))), ((int)(((byte)(133)))));
            this.raw6.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw6.FlatAppearance.BorderSize = 0;
            this.raw6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw6.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw6.ForeColor = System.Drawing.Color.White;
            this.raw6.Location = new System.Drawing.Point(0, 219);
            this.raw6.Name = "raw6";
            this.raw6.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw6.Size = new System.Drawing.Size(194, 44);
            this.raw6.TabIndex = 5;
            this.raw6.Text = "Oils";
            this.raw6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw6.UseVisualStyleBackColor = false;
            // 
            // raw5
            // 
            this.raw5.BackColor = System.Drawing.Color.Transparent;
            this.raw5.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw5.FlatAppearance.BorderSize = 0;
            this.raw5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw5.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw5.ForeColor = System.Drawing.Color.White;
            this.raw5.Location = new System.Drawing.Point(0, 175);
            this.raw5.Name = "raw5";
            this.raw5.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw5.Size = new System.Drawing.Size(194, 44);
            this.raw5.TabIndex = 4;
            this.raw5.Text = "Fruit Type";
            this.raw5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw5.UseVisualStyleBackColor = false;
            // 
            // raw4
            // 
            this.raw4.BackColor = System.Drawing.Color.Transparent;
            this.raw4.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw4.FlatAppearance.BorderSize = 0;
            this.raw4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw4.ForeColor = System.Drawing.Color.White;
            this.raw4.Location = new System.Drawing.Point(0, 131);
            this.raw4.Name = "raw4";
            this.raw4.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw4.Size = new System.Drawing.Size(194, 44);
            this.raw4.TabIndex = 3;
            this.raw4.Text = "Flowers";
            this.raw4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw4.UseVisualStyleBackColor = false;
            // 
            // raw3
            // 
            this.raw3.BackColor = System.Drawing.Color.Transparent;
            this.raw3.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw3.FlatAppearance.BorderSize = 0;
            this.raw3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw3.ForeColor = System.Drawing.Color.White;
            this.raw3.Location = new System.Drawing.Point(0, 87);
            this.raw3.Name = "raw3";
            this.raw3.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw3.Size = new System.Drawing.Size(194, 44);
            this.raw3.TabIndex = 2;
            this.raw3.Text = "Wood Type";
            this.raw3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw3.UseVisualStyleBackColor = false;
            // 
            // raw2
            // 
            this.raw2.BackColor = System.Drawing.Color.Transparent;
            this.raw2.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw2.FlatAppearance.BorderSize = 0;
            this.raw2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw2.ForeColor = System.Drawing.Color.White;
            this.raw2.Location = new System.Drawing.Point(0, 43);
            this.raw2.Name = "raw2";
            this.raw2.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw2.Size = new System.Drawing.Size(194, 44);
            this.raw2.TabIndex = 1;
            this.raw2.Text = "Leaves";
            this.raw2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw2.UseVisualStyleBackColor = false;
            // 
            // raw1
            // 
            this.raw1.BackColor = System.Drawing.Color.Transparent;
            this.raw1.Dock = System.Windows.Forms.DockStyle.Top;
            this.raw1.FlatAppearance.BorderSize = 0;
            this.raw1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.raw1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.raw1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raw1.ForeColor = System.Drawing.Color.White;
            this.raw1.Location = new System.Drawing.Point(0, 0);
            this.raw1.Name = "raw1";
            this.raw1.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.raw1.Size = new System.Drawing.Size(194, 43);
            this.raw1.TabIndex = 0;
            this.raw1.Text = "Herbs";
            this.raw1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.raw1.UseVisualStyleBackColor = false;
            // 
            // panelRawMain
            // 
            this.panelRawMain.BackColor = System.Drawing.Color.Transparent;
            this.panelRawMain.Controls.Add(this.butRaw);
            this.panelRawMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelRawMain.Location = new System.Drawing.Point(0, 315);
            this.panelRawMain.Name = "panelRawMain";
            this.panelRawMain.Size = new System.Drawing.Size(194, 48);
            this.panelRawMain.TabIndex = 3;
            // 
            // butRaw
            // 
            this.butRaw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(109)))), ((int)(((byte)(192)))));
            this.butRaw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.butRaw.FlatAppearance.BorderSize = 0;
            this.butRaw.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butRaw.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butRaw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butRaw.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butRaw.ForeColor = System.Drawing.Color.White;
            this.butRaw.Location = new System.Drawing.Point(0, 0);
            this.butRaw.Name = "butRaw";
            this.butRaw.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.butRaw.Size = new System.Drawing.Size(194, 48);
            this.butRaw.TabIndex = 1;
            this.butRaw.Text = "Materials";
            this.butRaw.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.butRaw.UseVisualStyleBackColor = false;
            // 
            // panelProdSub
            // 
            this.panelProdSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(77)))), ((int)(((byte)(133)))));
            this.panelProdSub.Controls.Add(this.prod6);
            this.panelProdSub.Controls.Add(this.prod5);
            this.panelProdSub.Controls.Add(this.prod4);
            this.panelProdSub.Controls.Add(this.prod3);
            this.panelProdSub.Controls.Add(this.prod2);
            this.panelProdSub.Controls.Add(this.prod1);
            this.panelProdSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelProdSub.Location = new System.Drawing.Point(0, 48);
            this.panelProdSub.Name = "panelProdSub";
            this.panelProdSub.Size = new System.Drawing.Size(194, 267);
            this.panelProdSub.TabIndex = 2;
            // 
            // prod6
            // 
            this.prod6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(77)))), ((int)(((byte)(133)))));
            this.prod6.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod6.FlatAppearance.BorderSize = 0;
            this.prod6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod6.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod6.ForeColor = System.Drawing.Color.White;
            this.prod6.Location = new System.Drawing.Point(0, 220);
            this.prod6.Name = "prod6";
            this.prod6.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod6.Size = new System.Drawing.Size(194, 44);
            this.prod6.TabIndex = 5;
            this.prod6.Text = "Guli or Pill";
            this.prod6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod6.UseVisualStyleBackColor = false;
            // 
            // prod5
            // 
            this.prod5.BackColor = System.Drawing.Color.Transparent;
            this.prod5.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod5.FlatAppearance.BorderSize = 0;
            this.prod5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod5.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod5.ForeColor = System.Drawing.Color.White;
            this.prod5.Location = new System.Drawing.Point(0, 176);
            this.prod5.Name = "prod5";
            this.prod5.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod5.Size = new System.Drawing.Size(194, 44);
            this.prod5.TabIndex = 4;
            this.prod5.Text = "Tablets";
            this.prod5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod5.UseVisualStyleBackColor = false;
            // 
            // prod4
            // 
            this.prod4.BackColor = System.Drawing.Color.Transparent;
            this.prod4.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod4.FlatAppearance.BorderSize = 0;
            this.prod4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod4.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod4.ForeColor = System.Drawing.Color.White;
            this.prod4.Location = new System.Drawing.Point(0, 132);
            this.prod4.Name = "prod4";
            this.prod4.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod4.Size = new System.Drawing.Size(194, 44);
            this.prod4.TabIndex = 3;
            this.prod4.Text = "Powder";
            this.prod4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod4.UseVisualStyleBackColor = false;
            // 
            // prod3
            // 
            this.prod3.BackColor = System.Drawing.Color.Transparent;
            this.prod3.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod3.FlatAppearance.BorderSize = 0;
            this.prod3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod3.ForeColor = System.Drawing.Color.White;
            this.prod3.Location = new System.Drawing.Point(0, 88);
            this.prod3.Name = "prod3";
            this.prod3.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod3.Size = new System.Drawing.Size(194, 44);
            this.prod3.TabIndex = 2;
            this.prod3.Text = "Tonic and Oil";
            this.prod3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod3.UseVisualStyleBackColor = false;
            // 
            // prod2
            // 
            this.prod2.BackColor = System.Drawing.Color.Transparent;
            this.prod2.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod2.FlatAppearance.BorderSize = 0;
            this.prod2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod2.ForeColor = System.Drawing.Color.White;
            this.prod2.Location = new System.Drawing.Point(0, 44);
            this.prod2.Name = "prod2";
            this.prod2.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod2.Size = new System.Drawing.Size(194, 44);
            this.prod2.TabIndex = 1;
            this.prod2.Text = "Creem and Gel";
            this.prod2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod2.UseVisualStyleBackColor = false;
            // 
            // prod1
            // 
            this.prod1.BackColor = System.Drawing.Color.Transparent;
            this.prod1.Dock = System.Windows.Forms.DockStyle.Top;
            this.prod1.FlatAppearance.BorderSize = 0;
            this.prod1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.prod1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prod1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prod1.ForeColor = System.Drawing.Color.White;
            this.prod1.Location = new System.Drawing.Point(0, 0);
            this.prod1.Name = "prod1";
            this.prod1.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.prod1.Size = new System.Drawing.Size(194, 44);
            this.prod1.TabIndex = 0;
            this.prod1.Text = "Balm";
            this.prod1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prod1.UseVisualStyleBackColor = false;
            this.prod1.Click += new System.EventHandler(this.button2_Click);
            // 
            // panelProdMain
            // 
            this.panelProdMain.BackColor = System.Drawing.Color.Transparent;
            this.panelProdMain.Controls.Add(this.butProd);
            this.panelProdMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelProdMain.Location = new System.Drawing.Point(0, 0);
            this.panelProdMain.Name = "panelProdMain";
            this.panelProdMain.Size = new System.Drawing.Size(194, 48);
            this.panelProdMain.TabIndex = 1;
            this.panelProdMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelProdMain_MouseClick);
            // 
            // butProd
            // 
            this.butProd.BackColor = System.Drawing.Color.Transparent;
            this.butProd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.butProd.FlatAppearance.BorderSize = 0;
            this.butProd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butProd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butProd.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butProd.ForeColor = System.Drawing.Color.White;
            this.butProd.Location = new System.Drawing.Point(0, 0);
            this.butProd.Name = "butProd";
            this.butProd.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.butProd.Size = new System.Drawing.Size(194, 48);
            this.butProd.TabIndex = 1;
            this.butProd.Text = "Products";
            this.butProd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.butProd.UseVisualStyleBackColor = false;
            this.butProd.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panelAllData);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 147);
            this.panel2.TabIndex = 0;
            // 
            // panelAllData
            // 
            this.panelAllData.Controls.Add(this.butAllData);
            this.panelAllData.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelAllData.Location = new System.Drawing.Point(0, 99);
            this.panelAllData.Name = "panelAllData";
            this.panelAllData.Size = new System.Drawing.Size(194, 48);
            this.panelAllData.TabIndex = 0;
            // 
            // butAllData
            // 
            this.butAllData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.butAllData.FlatAppearance.BorderSize = 0;
            this.butAllData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butAllData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(91)))), ((int)(((byte)(103)))));
            this.butAllData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAllData.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAllData.ForeColor = System.Drawing.Color.White;
            this.butAllData.Location = new System.Drawing.Point(0, 0);
            this.butAllData.Name = "butAllData";
            this.butAllData.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.butAllData.Size = new System.Drawing.Size(194, 48);
            this.butAllData.TabIndex = 0;
            this.butAllData.Text = "All Data";
            this.butAllData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.butAllData.UseVisualStyleBackColor = true;
            this.butAllData.Click += new System.EventHandler(this.butAllData_Click);
            // 
            // AdminDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1068, 749);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.typeShow);
            this.Controls.Add(this.gunaVSeparator1);
            this.MinimumSize = new System.Drawing.Size(1084, 561);
            this.Name = "AdminDatabase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDatabase";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panelUserData.ResumeLayout(false);
            this.panelBuySellData.ResumeLayout(false);
            this.panelRawSub.ResumeLayout(false);
            this.panelRawMain.ResumeLayout(false);
            this.panelProdSub.ResumeLayout(false);
            this.panelProdMain.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panelAllData.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
        private System.Windows.Forms.Label typeShow;
        private Guna.UI.WinForms.GunaDataGridView dataGrid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelProdMain;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button butProd;
        private System.Windows.Forms.Panel panelBuySellData;
        private System.Windows.Forms.Panel panelProdSub;
        private System.Windows.Forms.Button prod1;
        private System.Windows.Forms.Button prod4;
        private System.Windows.Forms.Button prod3;
        private System.Windows.Forms.Button prod2;
        private System.Windows.Forms.Button prod6;
        private System.Windows.Forms.Button prod5;
        private System.Windows.Forms.Panel panelRawSub;
        private System.Windows.Forms.Button raw6;
        private System.Windows.Forms.Button raw5;
        private System.Windows.Forms.Button raw4;
        private System.Windows.Forms.Button raw3;
        private System.Windows.Forms.Button raw2;
        private System.Windows.Forms.Button raw1;
        private System.Windows.Forms.Panel panelRawMain;
        private System.Windows.Forms.Button butRaw;
        private System.Windows.Forms.Panel panelUserData;
        private System.Windows.Forms.Button user4;
        private System.Windows.Forms.Button user3;
        private System.Windows.Forms.Button user2;
        private System.Windows.Forms.Button user1;
        private System.Windows.Forms.Panel panelAllData;
        private System.Windows.Forms.Button butAllData;
    }
}