﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;

namespace AdminView
{
    public partial class AdminMenu : Form
    {
        Calculations ob1 = new Calculations();
        private Form activeForm = null;

        private int i = 0, j = 0;
        private string nic = null;

        public AdminMenu(string nic)
        {
            InitializeComponent();
            cutomizeInterface();
            this.Text = String.Empty;
            this.ControlBox = false;
            clickHome();
            this.nic = nic;
        }

        #region ControlBox Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void button7_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        #endregion

        #region Panel Customize Section
        private void cutomizeInterface()
        {
            dataSubMenu.Visible = false;
            //userSubMenu.Visible = false;
            eorderSubMenu.Visible = false;
            reportSubMenu.Visible = false;
            logoutPic.Parent = btLogout;
            mainDate.Text = ob1.getDate();
        }

        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            containerPanel.Controls.Add(childForm);
            containerPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void SubMenuHide()
        {
            if (dataSubMenu.Visible == true)
            {
                dataSubMenu.Visible = false;
            }/*
            if (userSubMenu.Visible == true)
            {
                userSubMenu.Visible = false;
            }*/
            if (eorderSubMenu.Visible == true)
            {
                eorderSubMenu.Visible = false;
            }
            if (reportSubMenu.Visible == true)
            {
                reportSubMenu.Visible = false;
            }
        }

        private void SubManuShow(Panel submenu)
        {
            int i = 0;
            Panel[] tmp = { reportSubMenu, eorderSubMenu, dataSubMenu,  };
            for(i=0;i<tmp.Length;++i)
            {
                if (tmp[i] != submenu)
                {
                    tmp[i].Visible = false;
                }
            }

            if (submenu.Visible != true)
            {
                submenu.Visible = true;
            }
            else
            {
                submenu.Visible = false;
            }
        }
        #endregion

        #region ColorCustomize Section
        private void ButColorNull()
        {
            Button[] but1 = { button14, button15, button16, button17, button19, button6, button5, button4 };
            Button[] but2 = { mSells, mRequets, home, userMain, butOther };
            for (i = 0; i < but1.Length; ++i)
            {
                but1[i].BackColor = Color.FromArgb(0, 23, 61);
                but1[i].ForeColor = Color.FromArgb(185, 209, 234);
            }
            for (i = 0; i < but2.Length; ++i)
            {
                but2[i].BackColor = Color.FromArgb(0, 0, 33);
                but2[i].ForeColor = Color.FromArgb(191, 205, 219);
            }
        }

        private void butColor(Button but)
        {
            ButColorNull();
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void btLogout_MouseMove(object sender, MouseEventArgs e)
        {
            panelLogout.BackColor = Color.FromArgb(0, 130, 185);
        }

        private void btLogout_MouseLeave(object sender, EventArgs e)
        {
            panelLogout.BackColor = Color.White;
        }

        private void logoutPic_MouseMove(object sender, MouseEventArgs e)
        {
            panelLogout.BackColor = Color.FromArgb(0, 130, 185);
        }

        private void logoutPic_MouseLeave(object sender, EventArgs e)
        {
            panelLogout.BackColor = Color.White;
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(72, 91, 103);
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(0, 0, 33);
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(72, 91, 103);
        }

        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(72, 91, 103);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(0, 0, 33);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            panelUser.BackColor = Color.FromArgb(0, 0, 33);
        }
        #endregion

        #region AdminProfile Section
        private void LogOut()
        {
            FormArrange.loginPage.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openFroms(new AdminProfile(nic));
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            openFroms(new AdminProfile(nic));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFroms(new AdminProfile(nic));
        }

        private void btLogout_Click(object sender, EventArgs e)
        {
            LogOut();
        }

        private void logoutPic_Click(object sender, EventArgs e)
        {
            LogOut();
        }
        #endregion

        #region Function Section
        private void clickHome()
        {
            SubMenuHide();
            butColor(home);
            if(activeForm != null)
            { activeForm.Close(); }
        }
        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            SubManuShow(dataSubMenu);
        }

        #region DatabaseSubMenu
        private void button4_Click(object sender, EventArgs e)
        {
            openFroms(new AdminDatabase("user"));
            butColor(button4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            openFroms(new AdminDatabase("sell"));
            butColor(button5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            openFroms(new AdminDatabase("buy"));
            butColor(button6);
        }
        #endregion

        private void userMain_Click(object sender, EventArgs e)
        {
            //SubManuShow(userSubMenu);
            butColor(userMain);
            openFroms(new AdminDeleteUser());
        }

        #region UserManageSubMenu
        private void button12_Click(object sender, EventArgs e)
        {
            //butColor(button12);
            openFroms(new AdminAddUser());
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //butColor(button11);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //butColor(button10);
            openFroms(new AdminDeleteUser());
        }
        #endregion

        private void reportMain_Click(object sender, EventArgs e)
        {
            SubManuShow(reportSubMenu);
        }
        #region ReportSubMenu
        #endregion

        private void home_Click(object sender, EventArgs e)
        {
            clickHome();
        }

        private void eorderMain_Click(object sender, EventArgs e)
        {
            SubManuShow(eorderSubMenu);
        }
        #region eOrderSubMenu
        private void button14_Click(object sender, EventArgs e)
        {
            butColor(button14);
            openFroms(new AdminDeleteEOrder());
        }

        private void button19_Click(object sender, EventArgs e)
        {
            butColor(button19);
            openFroms(new AdminReportGeneral());
        }

        private void mSells_Click(object sender, EventArgs e)
        {
            butColor(mSells);
            openFroms(new AdminManageBuys());
        }

        private void butSuperAdmin_Click(object sender, EventArgs e)
        {
            butColor(butOther);
            openFroms(new AdminOther());
        }

        private void button16_Click(object sender, EventArgs e)
        {
            butColor(button16);
            openFroms(new AdminOther());
        }
        #endregion
    }
}
