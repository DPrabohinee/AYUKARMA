﻿using System;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminMenu2 : Form
    {
        private String id = null; // for admin id

        Calculations ob1 = new Calculations(); // load calulation class

        public AdminMenu2()
        {
            InitializeComponent();
            //this.id = id; // get admin id from login page
            setDate(); // set date from the start
        }

        // set date of the System Usage Analyze section
        private void setDate()
        {
            amDate.Text = ob1.getDate(); // get date
        }
    }
}
