﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminOther : Form
    {
        Message msg = new Message();
        SQLClass sql = new SQLClass();
        private int i = 0, j = 0;
        //private Form activeForm = null;

        public AdminOther()
        {
            InitializeComponent();
        }

        /*
#region Customize Panel Section
private void openFroms(Form childForm)
{
   if (activeForm != null)
   {
       activeForm.Close(); // clear-up the varible to store childForm
   }
   activeForm = childForm; // save childForm in activeForm varible
   childForm.TopLevel = false; // stop childForm from behaving like a controler
   childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
   childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
   panelBase.Controls.Add(childForm);
   panelBase.Tag = childForm;
   childForm.BringToFront();
   childForm.Show();
}
#endregion
*/

        private void addDoctor()
        {
            _ = sql.insertDoctor(txt1.Text, int.Parse(txt2.Text), txt3.Text, txt4.Text, txt7.Text, decimal.Parse(txt5.Text), decimal.Parse(txt6.Text));
        }

        private void addCenter()
        {
            _ = sql.insertCenter(txt11.Text, int.Parse(txt12.Text), txt13.Text, txt14.Text, txt17.Text, decimal.Parse(txt15.Text), decimal.Parse(txt16.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addCenter();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addDoctor();
        }
    }
}
