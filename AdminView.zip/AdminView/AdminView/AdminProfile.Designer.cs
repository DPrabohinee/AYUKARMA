﻿
namespace AdminView
{
    partial class AdminProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.labName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labNic = new System.Windows.Forms.Label();
            this.labFname = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labEmail = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labDob = new System.Windows.Forms.Label();
            this.labAdd1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labAdd2 = new System.Windows.Forms.Label();
            this.labAdd3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.adminData = new Guna.UI.WinForms.GunaDataGridView();
            this.labAdmin = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.adminData)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaButton1
            // 
            this.gunaButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(896, 468);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 20;
            this.gunaButton1.Size = new System.Drawing.Size(160, 42);
            this.gunaButton1.TabIndex = 1;
            this.gunaButton1.Text = "Close";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // gunaButton2
            // 
            this.gunaButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(730, 468);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 20;
            this.gunaButton2.Size = new System.Drawing.Size(160, 42);
            this.gunaButton2.TabIndex = 1;
            this.gunaButton2.Text = "Edit";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // labName
            // 
            this.labName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labName.AutoSize = true;
            this.labName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labName.Location = new System.Drawing.Point(165, 43);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(292, 29);
            this.labName.TabIndex = 2;
            this.labName.Text = "Ravishanka Kannangara";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(166, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Full Name :";
            // 
            // labNic
            // 
            this.labNic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labNic.AutoSize = true;
            this.labNic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labNic.Location = new System.Drawing.Point(166, 72);
            this.labNic.Name = "labNic";
            this.labNic.Size = new System.Drawing.Size(117, 20);
            this.labNic.TabIndex = 2;
            this.labNic.Text = "0123564987v";
            // 
            // labFname
            // 
            this.labFname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labFname.AutoSize = true;
            this.labFname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFname.Location = new System.Drawing.Point(195, 154);
            this.labFname.Name = "labFname";
            this.labFname.Size = new System.Drawing.Size(272, 20);
            this.labFname.TabIndex = 2;
            this.labFname.Text = "Yasas Ravishanka Lokukankanamge";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(168, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Email :";
            // 
            // labEmail
            // 
            this.labEmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labEmail.AutoSize = true;
            this.labEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labEmail.Location = new System.Drawing.Point(195, 224);
            this.labEmail.Name = "labEmail";
            this.labEmail.Size = new System.Drawing.Size(184, 20);
            this.labEmail.TabIndex = 2;
            this.labEmail.Text = "someone@example.com";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(417, 285);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "Date of Birth :";
            // 
            // labDob
            // 
            this.labDob.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labDob.AutoSize = true;
            this.labDob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labDob.Location = new System.Drawing.Point(450, 305);
            this.labDob.Name = "labDob";
            this.labDob.Size = new System.Drawing.Size(89, 20);
            this.labDob.TabIndex = 2;
            this.labDob.Text = "01/01/1997";
            // 
            // labAdd1
            // 
            this.labAdd1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labAdd1.AutoSize = true;
            this.labAdd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labAdd1.Location = new System.Drawing.Point(193, 305);
            this.labAdd1.Name = "labAdd1";
            this.labAdd1.Size = new System.Drawing.Size(64, 20);
            this.labAdd1.TabIndex = 3;
            this.labAdd1.Text = "No. 356";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(166, 285);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 20);
            this.label11.TabIndex = 4;
            this.label11.Text = "Address :";
            // 
            // labAdd2
            // 
            this.labAdd2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labAdd2.AutoSize = true;
            this.labAdd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labAdd2.Location = new System.Drawing.Point(193, 325);
            this.labAdd2.Name = "labAdd2";
            this.labAdd2.Size = new System.Drawing.Size(94, 20);
            this.labAdd2.TabIndex = 3;
            this.labAdd2.Text = "Mathugama";
            // 
            // labAdd3
            // 
            this.labAdd3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labAdd3.AutoSize = true;
            this.labAdd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labAdd3.Location = new System.Drawing.Point(193, 345);
            this.labAdd3.Name = "labAdd3";
            this.labAdd3.Size = new System.Drawing.Size(77, 20);
            this.labAdd3.TabIndex = 7;
            this.labAdd3.Text = "Kaluthara";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(615, 183);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 20);
            this.label17.TabIndex = 2;
            this.label17.Text = "Activity Log :";
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(119, 12);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(10, 498);
            this.gunaVSeparator1.TabIndex = 9;
            // 
            // adminData
            // 
            this.adminData.AllowUserToAddRows = false;
            this.adminData.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.adminData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.adminData.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.adminData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.adminData.BackgroundColor = System.Drawing.Color.White;
            this.adminData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.adminData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.adminData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.adminData.ColumnHeadersHeight = 21;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.adminData.DefaultCellStyle = dataGridViewCellStyle6;
            this.adminData.EnableHeadersVisualStyles = false;
            this.adminData.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminData.Location = new System.Drawing.Point(619, 211);
            this.adminData.Name = "adminData";
            this.adminData.ReadOnly = true;
            this.adminData.RowHeadersVisible = false;
            this.adminData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.adminData.Size = new System.Drawing.Size(427, 190);
            this.adminData.TabIndex = 10;
            this.adminData.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.adminData.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.adminData.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.adminData.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.adminData.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.adminData.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.adminData.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.adminData.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminData.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.adminData.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.adminData.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.adminData.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.adminData.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.adminData.ThemeStyle.HeaderStyle.Height = 21;
            this.adminData.ThemeStyle.ReadOnly = true;
            this.adminData.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.adminData.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.adminData.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.adminData.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.adminData.ThemeStyle.RowsStyle.Height = 22;
            this.adminData.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminData.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // labAdmin
            // 
            this.labAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labAdmin.AutoSize = true;
            this.labAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labAdmin.Location = new System.Drawing.Point(166, 92);
            this.labAdmin.Name = "labAdmin";
            this.labAdmin.Size = new System.Drawing.Size(101, 20);
            this.labAdmin.TabIndex = 2;
            this.labAdmin.Text = "Super Admin";
            // 
            // AdminProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1068, 522);
            this.Controls.Add(this.adminData);
            this.Controls.Add(this.gunaVSeparator1);
            this.Controls.Add(this.labAdd3);
            this.Controls.Add(this.labAdd2);
            this.Controls.Add(this.labAdd1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.labDob);
            this.Controls.Add(this.labEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labFname);
            this.Controls.Add(this.labAdmin);
            this.Controls.Add(this.labNic);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labName);
            this.Controls.Add(this.gunaButton2);
            this.Controls.Add(this.gunaButton1);
            this.MinimumSize = new System.Drawing.Size(1084, 561);
            this.Name = "AdminProfile";
            this.Text = "AdminProfile";
            this.Load += new System.EventHandler(this.AdminProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.adminData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labNic;
        private System.Windows.Forms.Label labFname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labDob;
        private System.Windows.Forms.Label labAdd1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labAdd2;
        private System.Windows.Forms.Label labAdd3;
        private System.Windows.Forms.Label label17;
        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
        private Guna.UI.WinForms.GunaDataGridView adminData;
        private System.Windows.Forms.Label labAdmin;
    }
}