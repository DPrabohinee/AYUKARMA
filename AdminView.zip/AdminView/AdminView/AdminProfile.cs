﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class AdminProfile : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();

        private Form activeForm = null;
        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");
        private string nic = null;

        public AdminProfile(string s1)
        {
            InitializeComponent();
            setVarible();
            this.nic = s1;
        }

        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            this.Controls.Add(childForm);
            this.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void setVarible()
        {
            string[] s = sql.getAdminDetails(nic);
            int t = 0;
            t = int.Parse(s[0]);
            if(t == 1)
            {
                labName.Text = s[1] + " " + s[3];
                labNic.Text = nic;
                if (sql.getPosition(nic) == 2)
                {
                    labAdmin.Text = "Super Admin";
                }
                else if (sql.getPosition(nic) == 1)
                {
                    labAdmin.Text = "Admin";
                }
                if(s[2] == null)
                {
                    labFname.Text = s[1] + " " + s[3];
                }
                else
                {
                    labFname.Text = s[1] + " " + s[2] + " " + s[3];
                }
                labDob.Text = s[4];
                //labGender.Text = s[9];
                labAdd1.Text = s[5];
                labAdd2.Text = s[6];
                labAdd3.Text = s[7];
                labEmail.Text = s[8];
            }
            loadData();
        }

        private void loadData()
        {
            string que = "select * from adminactivitilog";
            string table = "adminactivitylog";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                adminData.DataSource = ds;
                adminData.DataMember = table;
            }
            catch (Exception e)
            {
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            openFroms(new AdminProfileEdit(nic));
            this.Refresh();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Unnecessary
        private void AdminProfile_Load(object sender, EventArgs e)
        { }
        #endregion
    }
}
