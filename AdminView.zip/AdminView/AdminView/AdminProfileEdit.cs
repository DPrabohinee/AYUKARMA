﻿using System;
using System.Windows.Forms;

namespace AdminView
{
    public partial class AdminProfileEdit : Form
    {
        SQLClass sql = new SQLClass();

        private string nic = null;

        public AdminProfileEdit(string nic)
        {
            InitializeComponent();
            this.nic = nic;
            loadData();
            clear();
        }

        #region Function Section

        private void clear()
        {
            warning1.Text = null;
            warning6.Text = null;
            warning5.Text = null;
            warning3.Text = null;
            warning2.Text = null;
        }

        private void loadData()
        {
            string[] s = sql.getAdminDetails(nic);
            if(int.Parse(s[0]) == 1)
            {
                fname.Text = s[1];
                mname.Text = s[2];
                lname.Text = s[3];
                addl1.Text = s[5];
                addl2.Text = s[6];
                addl3.Text = s[7];
                email.Text = s[8];
                dob.Text = s[4];
                //gender.Text = s[9];
            }
        }
        #endregion

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            AdminChangePassword ob1 = new AdminChangePassword(nic);
            ob1.Show();
        }
    }
}
