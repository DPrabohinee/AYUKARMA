﻿
namespace AdminView
{
    partial class AdminReportGeneral
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lab6 = new System.Windows.Forms.Label();
            this.lab4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lab7 = new System.Windows.Forms.Label();
            this.lab3 = new System.Windows.Forms.Label();
            this.lab5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lab1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pan5 = new System.Windows.Forms.Panel();
            this.but5 = new System.Windows.Forms.Button();
            this.pan6 = new System.Windows.Forms.Panel();
            this.but6 = new System.Windows.Forms.Button();
            this.pan7 = new System.Windows.Forms.Panel();
            this.but7 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pan4 = new System.Windows.Forms.Panel();
            this.but4 = new System.Windows.Forms.Button();
            this.pan3 = new System.Windows.Forms.Panel();
            this.but3 = new System.Windows.Forms.Button();
            this.pan2 = new System.Windows.Forms.Panel();
            this.but2 = new System.Windows.Forms.Button();
            this.pan1 = new System.Windows.Forms.Panel();
            this.but1 = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pan8 = new System.Windows.Forms.Panel();
            this.but8 = new System.Windows.Forms.Button();
            this.txt = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pan5.SuspendLayout();
            this.pan6.SuspendLayout();
            this.pan7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pan4.SuspendLayout();
            this.pan3.SuspendLayout();
            this.pan2.SuspendLayout();
            this.pan1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.pan8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1051, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "General Usage Report";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lab6);
            this.panel1.Controls.Add(this.lab4);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.lab7);
            this.panel1.Controls.Add(this.lab3);
            this.panel1.Controls.Add(this.lab5);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.lab1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1051, 258);
            this.panel1.TabIndex = 1;
            // 
            // lab6
            // 
            this.lab6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab6.Location = new System.Drawing.Point(848, 82);
            this.lab6.Name = "lab6";
            this.lab6.Size = new System.Drawing.Size(194, 28);
            this.lab6.TabIndex = 0;
            this.lab6.Text = "00000";
            this.lab6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab4
            // 
            this.lab4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab4.Location = new System.Drawing.Point(303, 137);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(194, 28);
            this.lab4.TabIndex = 0;
            this.lab4.Text = "00000";
            this.lab4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(550, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(259, 28);
            this.label8.TabIndex = 0;
            this.label8.Text = "All Time Web Transaction :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(17, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(280, 28);
            this.label14.TabIndex = 0;
            this.label14.Text = "All Time Desktop Logins :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab7
            // 
            this.lab7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab7.Location = new System.Drawing.Point(848, 140);
            this.lab7.Name = "lab7";
            this.lab7.Size = new System.Drawing.Size(194, 28);
            this.lab7.TabIndex = 0;
            this.lab7.Text = "00000";
            this.lab7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab3
            // 
            this.lab3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab3.Location = new System.Drawing.Point(303, 82);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(194, 28);
            this.lab3.TabIndex = 0;
            this.lab3.Text = "00000";
            this.lab3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab5
            // 
            this.lab5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab5.Location = new System.Drawing.Point(848, 27);
            this.lab5.Name = "lab5";
            this.lab5.Size = new System.Drawing.Size(194, 28);
            this.lab5.TabIndex = 0;
            this.lab5.Text = "00000";
            this.lab5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(550, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(259, 28);
            this.label11.TabIndex = 0;
            this.label11.Text = "All Time Desktop Transaction :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab1
            // 
            this.lab1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab1.Location = new System.Drawing.Point(303, 27);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(194, 28);
            this.lab1.TabIndex = 0;
            this.lab1.Text = "00000";
            this.lab1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(280, 28);
            this.label10.TabIndex = 0;
            this.label10.Text = "All Time Web Login:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(550, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(259, 28);
            this.label6.TabIndex = 0;
            this.label6.Text = "All Time Transaction :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "All Time Logins :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.pan8);
            this.panel2.Controls.Add(this.pan5);
            this.panel2.Controls.Add(this.pan6);
            this.panel2.Controls.Add(this.pan7);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 310);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1051, 100);
            this.panel2.TabIndex = 2;
            // 
            // pan5
            // 
            this.pan5.BackColor = System.Drawing.Color.Gray;
            this.pan5.Controls.Add(this.but5);
            this.pan5.Dock = System.Windows.Forms.DockStyle.Right;
            this.pan5.Location = new System.Drawing.Point(306, 50);
            this.pan5.Name = "pan5";
            this.pan5.Size = new System.Drawing.Size(280, 50);
            this.pan5.TabIndex = 3;
            // 
            // but5
            // 
            this.but5.BackColor = System.Drawing.Color.White;
            this.but5.Dock = System.Windows.Forms.DockStyle.Top;
            this.but5.FlatAppearance.BorderSize = 0;
            this.but5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but5.Location = new System.Drawing.Point(0, 0);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(280, 43);
            this.but5.TabIndex = 0;
            this.but5.Text = "All Time Desktop Transaction";
            this.but5.UseVisualStyleBackColor = false;
            this.but5.Click += new System.EventHandler(this.but5_Click);
            // 
            // pan6
            // 
            this.pan6.BackColor = System.Drawing.Color.Gray;
            this.pan6.Controls.Add(this.but6);
            this.pan6.Dock = System.Windows.Forms.DockStyle.Right;
            this.pan6.Location = new System.Drawing.Point(586, 50);
            this.pan6.Name = "pan6";
            this.pan6.Size = new System.Drawing.Size(252, 50);
            this.pan6.TabIndex = 2;
            // 
            // but6
            // 
            this.but6.BackColor = System.Drawing.Color.White;
            this.but6.Dock = System.Windows.Forms.DockStyle.Top;
            this.but6.FlatAppearance.BorderSize = 0;
            this.but6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but6.Location = new System.Drawing.Point(0, 0);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(252, 43);
            this.but6.TabIndex = 0;
            this.but6.Text = "All Time Web Transaction";
            this.but6.UseVisualStyleBackColor = false;
            this.but6.Click += new System.EventHandler(this.but6_Click);
            // 
            // pan7
            // 
            this.pan7.BackColor = System.Drawing.Color.Gray;
            this.pan7.Controls.Add(this.but7);
            this.pan7.Dock = System.Windows.Forms.DockStyle.Right;
            this.pan7.Location = new System.Drawing.Point(838, 50);
            this.pan7.Name = "pan7";
            this.pan7.Size = new System.Drawing.Size(213, 50);
            this.pan7.TabIndex = 1;
            // 
            // but7
            // 
            this.but7.BackColor = System.Drawing.Color.White;
            this.but7.Dock = System.Windows.Forms.DockStyle.Top;
            this.but7.FlatAppearance.BorderSize = 0;
            this.but7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but7.Location = new System.Drawing.Point(0, 0);
            this.but7.Name = "but7";
            this.but7.Size = new System.Drawing.Size(213, 43);
            this.but7.TabIndex = 0;
            this.but7.Text = "All Time Transaction";
            this.but7.UseVisualStyleBackColor = false;
            this.but7.Click += new System.EventHandler(this.but7_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.pan4);
            this.panel3.Controls.Add(this.pan3);
            this.panel3.Controls.Add(this.pan2);
            this.panel3.Controls.Add(this.pan1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1051, 50);
            this.panel3.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(884, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(167, 43);
            this.panel8.TabIndex = 4;
            // 
            // pan4
            // 
            this.pan4.BackColor = System.Drawing.Color.Gray;
            this.pan4.Controls.Add(this.but4);
            this.pan4.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan4.Location = new System.Drawing.Point(668, 0);
            this.pan4.Name = "pan4";
            this.pan4.Size = new System.Drawing.Size(216, 50);
            this.pan4.TabIndex = 3;
            // 
            // but4
            // 
            this.but4.BackColor = System.Drawing.Color.White;
            this.but4.Dock = System.Windows.Forms.DockStyle.Top;
            this.but4.FlatAppearance.BorderSize = 0;
            this.but4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but4.Location = new System.Drawing.Point(0, 0);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(216, 43);
            this.but4.TabIndex = 0;
            this.but4.Text = "All Time Desktop Logins";
            this.but4.UseVisualStyleBackColor = false;
            this.but4.Click += new System.EventHandler(this.but4_Click);
            // 
            // pan3
            // 
            this.pan3.BackColor = System.Drawing.Color.Gray;
            this.pan3.Controls.Add(this.but3);
            this.pan3.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan3.Location = new System.Drawing.Point(472, 0);
            this.pan3.Name = "pan3";
            this.pan3.Size = new System.Drawing.Size(196, 50);
            this.pan3.TabIndex = 2;
            // 
            // but3
            // 
            this.but3.BackColor = System.Drawing.Color.White;
            this.but3.Dock = System.Windows.Forms.DockStyle.Top;
            this.but3.FlatAppearance.BorderSize = 0;
            this.but3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but3.Location = new System.Drawing.Point(0, 0);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(196, 43);
            this.but3.TabIndex = 0;
            this.but3.Text = "All Time Web Login";
            this.but3.UseVisualStyleBackColor = false;
            this.but3.Click += new System.EventHandler(this.but3_Click);
            // 
            // pan2
            // 
            this.pan2.BackColor = System.Drawing.Color.Gray;
            this.pan2.Controls.Add(this.but2);
            this.pan2.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan2.Location = new System.Drawing.Point(186, 0);
            this.pan2.Name = "pan2";
            this.pan2.Size = new System.Drawing.Size(286, 50);
            this.pan2.TabIndex = 1;
            // 
            // but2
            // 
            this.but2.BackColor = System.Drawing.Color.White;
            this.but2.Dock = System.Windows.Forms.DockStyle.Top;
            this.but2.FlatAppearance.BorderSize = 0;
            this.but2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but2.Location = new System.Drawing.Point(0, 0);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(286, 43);
            this.but2.TabIndex = 0;
            this.but2.Text = "All Time Web and Desktop Logins";
            this.but2.UseVisualStyleBackColor = false;
            this.but2.Click += new System.EventHandler(this.but2_Click);
            // 
            // pan1
            // 
            this.pan1.BackColor = System.Drawing.Color.Gray;
            this.pan1.Controls.Add(this.but1);
            this.pan1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan1.Location = new System.Drawing.Point(0, 0);
            this.pan1.Name = "pan1";
            this.pan1.Size = new System.Drawing.Size(186, 50);
            this.pan1.TabIndex = 0;
            // 
            // but1
            // 
            this.but1.BackColor = System.Drawing.Color.White;
            this.but1.Dock = System.Windows.Forms.DockStyle.Top;
            this.but1.FlatAppearance.BorderSize = 0;
            this.but1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but1.Location = new System.Drawing.Point(0, 0);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(186, 43);
            this.but1.TabIndex = 0;
            this.but1.Text = "All Time Logins";
            this.but1.UseVisualStyleBackColor = false;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 460);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            this.chart1.Size = new System.Drawing.Size(1051, 400);
            this.chart1.TabIndex = 3;
            this.chart1.Text = "chart1";
            // 
            // pan8
            // 
            this.pan8.BackColor = System.Drawing.Color.Gray;
            this.pan8.Controls.Add(this.but8);
            this.pan8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan8.Location = new System.Drawing.Point(0, 50);
            this.pan8.Name = "pan8";
            this.pan8.Size = new System.Drawing.Size(306, 50);
            this.pan8.TabIndex = 4;
            // 
            // but8
            // 
            this.but8.BackColor = System.Drawing.Color.White;
            this.but8.Dock = System.Windows.Forms.DockStyle.Top;
            this.but8.FlatAppearance.BorderSize = 0;
            this.but8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.but8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.but8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but8.Location = new System.Drawing.Point(0, 0);
            this.but8.Name = "but8";
            this.but8.Size = new System.Drawing.Size(306, 43);
            this.but8.TabIndex = 0;
            this.but8.Text = "All Time Desktop and Web Transaction";
            this.but8.UseVisualStyleBackColor = false;
            this.but8.Click += new System.EventHandler(this.but8_Click);
            // 
            // txt
            // 
            this.txt.Dock = System.Windows.Forms.DockStyle.Top;
            this.txt.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt.Location = new System.Drawing.Point(0, 410);
            this.txt.Name = "txt";
            this.txt.Size = new System.Drawing.Size(1051, 50);
            this.txt.TabIndex = 4;
            this.txt.Text = "name";
            this.txt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AdminReportGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1068, 749);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.txt);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1084, 561);
            this.Name = "AdminReportGeneral";
            this.Text = "AdminReportUser";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.pan5.ResumeLayout(false);
            this.pan6.ResumeLayout(false);
            this.pan7.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pan4.ResumeLayout(false);
            this.pan3.ResumeLayout(false);
            this.pan2.ResumeLayout(false);
            this.pan1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.pan8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lab6;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lab7;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.Label lab5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pan5;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Panel pan6;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.Panel pan7;
        private System.Windows.Forms.Button but7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel pan4;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.Panel pan3;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Panel pan2;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Panel pan1;
        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Panel pan8;
        private System.Windows.Forms.Button but8;
        private System.Windows.Forms.Label txt;
    }
}