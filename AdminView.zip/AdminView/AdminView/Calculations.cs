﻿using System;

namespace AdminView
{
    class Calculations
    {
        private int i = 0, j = 0;
        private String date = null;
        private String random = null;
        private String[] tmp1 = new String[120];

        // get today date to a string and return the value
        public String getDate()
        {
            date = DateTime.Now.ToString("dd/MM/yyyy");
            return date;
        }

        public String getRandom()
        {
            j = 324;
            for (i=0;i<120;++i)
            {
                tmp1[i] = (j).ToString();
                --j;
            }

            int t = 0;
            String s = DateTime.Now.ToString("ss");
            t = int.Parse(s);
            int t1 = (t / 2) * 3;

            random = DateTime.Now.ToString("ddMMyyyyHHmmss"+tmp1[t1]);
            return random;
        }

        public Boolean checkNIC(string nic)
        {
            Boolean t = false;
            int s1 = nic.Length;
            if (nic != null && nic != "")
            {
                if (s1 >= 10 && s1 <= 12)
                {
                    char[] s2 = nic.ToCharArray();
                    if (s1 == 10)
                    {
                        if (s2[s1-1] == 'v')
                        {
                            try
                            {
                                string tmp = s2[s1 - 1].ToString();
                                int s3 = int.Parse(tmp);
                                t = true;
                            }
                            catch (Exception e)
                            { t = false; }
                        }
                        else
                        { t = false; }
                    }
                    else
                    {
                        if (s1 == 12)
                        {
                            try
                            {
                                int s3 = int.Parse(nic);
                                t = true;
                            }
                            catch (Exception e)
                            { t = false; }
                        }
                        else
                        { t = false; }
                    }
                }
                else
                { t = false; }
            }
            else
            { t = false; }
            return t;
        }

        public int getAdminIntId(string s)
        {
            int t = 0;
            char[] s1 = s.ToCharArray();
            char[] s3 = new char[5];
            for (int i = 3; i < s1.Length; ++i)
            {
                s3[i - 3] = s1[i];
            }
            string s2 = new string(s3);
            t = int.Parse(s2);
            return t;
        }

        private string makeAdminID(int t)
        {
            string h = null;
            if (t.ToString().Length == 2)
            {
                h = "000" + t.ToString();
            }
            else if (t.ToString().Length == 1)
            {
                h = "0000" + t.ToString();
            }
            else if (t.ToString().Length == 3)
            {
                h = "00" + t.ToString();
            }
            else if (t.ToString().Length == 4)
            {
                h = "0" + t.ToString();
            }
            else if (t.ToString().Length == 5)
            {
                h = t.ToString();
            }
            string s = "AID" + h;
            return s;
        }

        public string func1()
        {
            int i;
            string s1 = null;
            int[] t = new int[100000];
            string[] s = new string[100000];
            //string[] s = new string[100000];
            for (i = 0; i < 9952; ++i)
            {
                t[i] = (i + 1);
                s[i] = makeAdminID(t[i]);
            }
            for (i = 0; i < t.Length; ++i)
            {
                if (t[i] == 0)
                {
                    s1 = s[i - 1];
                    break;
                }
            }
            return s1;
        }

    }
}
