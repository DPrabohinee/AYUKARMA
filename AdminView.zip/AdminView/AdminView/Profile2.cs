﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class Profile2 : Form
    {
        SQLClass sql = new SQLClass();
        EncryptClass ent = new EncryptClass();

        private string nic = null;

        public Profile2(string nic)
        {
            InitializeComponent();
            this.nic = nic;
            clear();
        }

        private void clear()
        {
            warning2.Text = null;
            warning1.Text = null;
        }

        private void setpassword()
        {
            clear();
            string np = txt1.Text;
            string np1 = txt2.Text;
            if(np == null || np == "")
            {
                warning1.Text = "* Enter a Password";
            }
            else if(np1 == null || np1 == "")
            {
                warning2.Text = "* Enter a Comform Password";
            }
            else if(np != np1)
            {
                warning1.Text = "* Password doesn't match";
            }
            else
            {
                _ = sql.setAdminPassword(nic, ent.Encrypt(np, nic));
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            setpassword();
        }

        private void txt1_Enter(object sender, EventArgs e)
        {
            if (txt1.Text == "Password")
            {
                txt1.Text = "";
                txt1.ForeColor = Color.Black;
                txt1.PasswordChar = '*';
                pan2.BackColor = Color.FromArgb(76, 175, 80);
            }
        }

        private void txt1_Leave(object sender, EventArgs e)
        {
            if (txt1.Text == "")
            {
                txt1.Text = "Password";
                txt1.PasswordChar = '\0';
                txt1.ForeColor = Color.Gray;
                pan2.BackColor = Color.Gray;
            }
        }

        private void txt2_Enter(object sender, EventArgs e)
        {
            if (txt1.Text == "Conform Password")
            {
                txt1.Text = "";
                txt1.ForeColor = Color.Black;
                txt1.PasswordChar = '*';
                pan2.BackColor = Color.FromArgb(76, 175, 80);
            }
        }

        private void txt2_Leave(object sender, EventArgs e)
        {
            if (txt1.Text == "")
            {
                txt1.Text = "Conform Password";
                txt1.PasswordChar = '\0';
                txt1.ForeColor = Color.Gray;
                pan2.BackColor = Color.Gray;
            }
        }
    }
}
