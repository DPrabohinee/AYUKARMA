﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class ResetPassword : Form
    {
        Calculations cal = new Calculations();
        SQLClass sql = new SQLClass();
        SendEmail mail = new SendEmail();

        private static Random random = new Random();
        private string code = null;
        private int se = 0;

        public ResetPassword()
        {
            InitializeComponent();
            customizeForm();
            this.Text = String.Empty;
            this.ControlBox = false;
        }

        #region Form Customize Section
        private void customizeForm()
        {
            gunaButton1.Text = "Send Code";
            clearFields();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }
        #endregion

        #region Function Section
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void clear()
        {
            warning1.Text = null;
            warning2.Text = null;
        }

        private void clearFields()
        {
            uname.Text = null;
            codeShow.Text = null;
            code = null;
            clear();
        }

        private void clickSend()
        {
            clear();
            if(cal.checkNIC(uname.Text) == true)
            {
                string[] email = sql.getAdminEmail(uname.Text);
                int t = int.Parse(email[0]);
                if(t == 1)
                {
                    code = RandomString(16);
                    mail.sendCodeEmail(email[1], code);
                    gunaButton1.Text = "Resend Code";
                    se = 0;
                }
                else if(t == 0)
                {
                    warning1.Text = "* Invalid NIC";
                }
            }
            else
            {
                warning1.Text = "* Invalid NIC";
            }
        }

        private void clickChange()
        {
            clear();
            if(code == null)
            {
                warning2.Text = "* get your code first";
            }
            else
            {
                if (se == 0)
                {
                    if (codeShow.Text == code)
                    {
                        ResetPassword2 ob3 = new ResetPassword2(uname.Text);
                        ob3.Show();
                        se = 0;
                        clearFields();
                    }
                    else
                    {
                        warning2.Text = "* Invalid Code";
                    }
                }
                else if(se == 1)
                {
                    string tmp = "don't change the email\nafter verification code was send";
                    warning2.Text = tmp;
                }
            }
        }

        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            customizeForm();
            FormArrange.loginPage.Show();
            this.Close();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            customizeForm();
            FormArrange.loginPage.Show();
            this.Close();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            clickSend();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            clickChange();
        }

        private void uname_TextChanged(object sender, EventArgs e)
        {
            se = 1;
            code = null;
        }
    }
}
