﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminView
{
    public partial class ResetPassword2 : Form
    {
        SQLClass sql = new SQLClass();
        Message msg = new Message();
        EncryptClass ent = new EncryptClass();

        string uname = null;

        public ResetPassword2(string s1)
        {
            InitializeComponent();
            this.uname = s1;
            this.Text = string.Empty;
            this.ControlBox = false;
            clearFields();
        }

        #region Function Section
        private void clear()
        {
            warning2.Text = null;
            warning1.Text = null;
        }

        private void clearFields()
        {
            npword.Text = null;
            cpword.Text = null;
            clear();
        }

        private void changePassword()
        {
            clear();
            string s1 = npword.Text;
            string s2 = cpword.Text;
            if(s1 == null || s1 == "")
            {
                warning1.Text = "* Enter a new Password";
            }
            else
            {
                if (s2 == null || s2 == "")
                {
                    warning2.Text = "* Conform the new Password";
                }
                else
                {
                    if(s1 == s2)
                    {
                        int t = sql.updateAdminPasswords(uname, ent.Encrypt(s1,uname));
                        if(t == 0)
                        {
                            msg.invalid_changePassword();
                        }
                        else if(t == 1)
                        {
                            clearFields();
                            msg.succes_changePassword();
                            this.Close();
                        }
                    }
                    else
                    {
                        warning2.Text = "* conform password dosn't match";
                    }
                }
            }
        }
        #endregion

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            changePassword();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
