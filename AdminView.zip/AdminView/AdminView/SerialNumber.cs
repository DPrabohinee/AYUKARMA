﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminView
{
    class SerialNumber
    {
        SQLClass sql = new SQLClass();

        private string[] t = null;
        private int i = 0, j = 0;

        public int getNumber(string snum)
        {
            int tmp = 0;
            string[] s = sql.getAdminNumber();
            char[,] s3 = null;
            for(i = 0; i < s.Length; ++i)
            {
                char[] s5 = snum.ToCharArray();
                for(j = 0; j < s5.Length; ++j)
                {
                    s3[i,j] = s5[j];
                }
            }
            char[] s4 = null;
            for(i = 3; i < s3.Length; ++i)
            {
                //s4[i - 3] = s3[i];
            }
            string s2 = s4.ToString();

            return tmp;
        }
    }
}
