﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class SuperAdminMenu : Form
    {
        Message msg = new Message();

        private Form activeForm = null;

        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        public SuperAdminMenu()
        {
            InitializeComponent();
            this.Text = String.Empty;
            this.ControlBox = false;
            colorCustomize(button9);
            loadData(1);
            loadDataLab();
        }

        #region ControlBox Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
        #endregion

        #region Customize Panels
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            panel5.Visible = false;
        }

        private void closeForm()
        {
            if(activeForm != null)
            {
                activeForm.Close();
            }
            panel5.Visible = true;
            colorCustomize(button9);
            loadData(1);
        }
        #endregion

        #region Color Setting Section
        private void colorCustomize(Button but)
        {
            button9.BackColor = Color.FromArgb(126, 147, 200);
            button3.BackColor = Color.FromArgb(126, 147, 200);
            button4.BackColor = Color.FromArgb(126, 147, 200);
            button5.BackColor = Color.FromArgb(126, 147, 200);
            button7.BackColor = Color.FromArgb(126, 147, 200);
            button8.BackColor = Color.FromArgb(126, 147, 200);
            but.BackColor = Color.White;
        }

        private void colorCustomizeAdmin(Button but)
        {
            button10.BackColor = Color.White;
            button11.BackColor = Color.White;
            but.BackColor = Color.FromArgb(126, 147, 200);
        }
        #endregion

        #region Function Section
        private void clearWarning()
        {
            warningtxt.Text = null;
        }

        private void loadData(int t)
        {
            clearWarning();
            string que = null;
            string table = null;
            if(t == 1)
            {
                que = "select adminID as Admin_ID,nicno as NIC_No,fname as First_Name,mname as Middle_Name,lname as Last_Name,dob as Date_of_Birth,aadline1 as Address_Line_01,aadline2 as Address_Line_02,aadline3 as Address_Line_03 from admins";
                table = "admins";
                colorCustomizeAdmin(button10);
            }
            else if(t == 2)
            {
                que = "select * from adminactivitylog";
                table = "adminactivitilog";
                colorCustomizeAdmin(button11);
            }
            if(t == 1 || t == 2)
            {
                try
                {
                    SqlDataAdapter dta = new SqlDataAdapter(que, con);
                    DataSet ds = new DataSet();
                    dta.Fill(ds, table);
                    dataAdmin.DataSource = ds;
                    dataAdmin.DataMember = table;
                }
                catch (Exception e)
                {
                    string x = Convert.ToString(e);
                    msg.invalid_data(x);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                warningtxt.Text = "* something went wrong, please contact your developer";
            }
        }

        private void loadDataLab()
        {
            string que = "select top 1 weblogin,desktoplogin,webselling,websbuying,desktopselling,desktopbuying,webspecialordres,desktopspecialordres from systemusage";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        int t = dr1.GetInt32(0);
                        int t1 = dr1.GetInt32(1);
                        int t2 = dr1.GetInt32(2);
                        int t3 = dr1.GetInt32(3);
                        int t4 = dr1.GetInt32(4);
                        int t5 = dr1.GetInt32(5);
                        int t6 = dr1.GetInt32(6);
                        int t7 = dr1.GetInt32(7);

                        lab1.Text = (t).ToString();
                        lab2.Text = (t1).ToString();
                        lab3.Text = (t2).ToString();
                        lab4.Text = (t4).ToString();
                        lab5.Text = (t3).ToString();
                        lab5.Text = (t5).ToString();
                        lab7.Text = (t6).ToString();
                        lab8.Text = (t7).ToString();
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                msg.invalid_data(s);
            }
            finally
            {
                con.Close();
            }
        }

        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            openFroms(new SuperAddAdmin());
            colorCustomize(button3);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            closeForm();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            openFroms(new SuperRemoveAdmin());
            colorCustomize(button5);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openFroms(new SuperUpdateAdmin());
            colorCustomize(button4);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.closeForm();
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            loadData(1);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            loadData(2);
        }
    }
}
