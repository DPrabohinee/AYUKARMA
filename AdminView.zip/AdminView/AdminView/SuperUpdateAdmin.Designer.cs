﻿
namespace AdminView
{
    partial class SuperUpdateAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.adminDataView = new Guna.UI.WinForms.GunaDataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.labelPosition = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelLname = new System.Windows.Forms.Label();
            this.labelMname = new System.Windows.Forms.Label();
            this.labelFname = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.posiwarn2 = new System.Windows.Forms.Label();
            this.posiwarn1 = new System.Windows.Forms.Label();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.selecPosition = new Guna.UI.WinForms.GunaComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.nicwarn2 = new System.Windows.Forms.Label();
            this.nicwarn1 = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.txtNic = new Guna.UI.WinForms.GunaTextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminDataView)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.adminDataView);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(543, 398);
            this.panel1.TabIndex = 0;
            // 
            // adminDataView
            // 
            this.adminDataView.AllowUserToAddRows = false;
            this.adminDataView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.adminDataView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.adminDataView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.adminDataView.BackgroundColor = System.Drawing.Color.White;
            this.adminDataView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminDataView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.adminDataView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.adminDataView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.adminDataView.ColumnHeadersHeight = 21;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.adminDataView.DefaultCellStyle = dataGridViewCellStyle3;
            this.adminDataView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adminDataView.EnableHeadersVisualStyles = false;
            this.adminDataView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminDataView.Location = new System.Drawing.Point(0, 25);
            this.adminDataView.Name = "adminDataView";
            this.adminDataView.ReadOnly = true;
            this.adminDataView.RowHeadersVisible = false;
            this.adminDataView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.adminDataView.Size = new System.Drawing.Size(543, 373);
            this.adminDataView.TabIndex = 1;
            this.adminDataView.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.adminDataView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.adminDataView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.adminDataView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.adminDataView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.adminDataView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.adminDataView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.adminDataView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminDataView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.adminDataView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.adminDataView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.adminDataView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.adminDataView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.adminDataView.ThemeStyle.HeaderStyle.Height = 21;
            this.adminDataView.ThemeStyle.ReadOnly = true;
            this.adminDataView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.adminDataView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.adminDataView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.adminDataView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.adminDataView.ThemeStyle.RowsStyle.Height = 22;
            this.adminDataView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.adminDataView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(543, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admins";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(543, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(528, 398);
            this.panel2.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.labelPosition);
            this.panel10.Controls.Add(this.label5);
            this.panel10.Controls.Add(this.labelLname);
            this.panel10.Controls.Add(this.labelMname);
            this.panel10.Controls.Add(this.labelFname);
            this.panel10.Controls.Add(this.label4);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(20, 130);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(508, 268);
            this.panel10.TabIndex = 5;
            // 
            // labelPosition
            // 
            this.labelPosition.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelPosition.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPosition.Location = new System.Drawing.Point(0, 125);
            this.labelPosition.Name = "labelPosition";
            this.labelPosition.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.labelPosition.Size = new System.Drawing.Size(508, 25);
            this.labelPosition.TabIndex = 10;
            this.labelPosition.Text = "current position";
            this.labelPosition.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(508, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Position - ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelLname
            // 
            this.labelLname.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelLname.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLname.Location = new System.Drawing.Point(0, 75);
            this.labelLname.Name = "labelLname";
            this.labelLname.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.labelLname.Size = new System.Drawing.Size(508, 25);
            this.labelLname.TabIndex = 8;
            this.labelLname.Text = "last name";
            this.labelLname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelMname
            // 
            this.labelMname.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelMname.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMname.Location = new System.Drawing.Point(0, 50);
            this.labelMname.Name = "labelMname";
            this.labelMname.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.labelMname.Size = new System.Drawing.Size(508, 25);
            this.labelMname.TabIndex = 7;
            this.labelMname.Text = "middle name";
            this.labelMname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelFname
            // 
            this.labelFname.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelFname.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFname.Location = new System.Drawing.Point(0, 25);
            this.labelFname.Name = "labelFname";
            this.labelFname.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.labelFname.Size = new System.Drawing.Size(508, 25);
            this.labelFname.TabIndex = 6;
            this.labelFname.Text = "first name";
            this.labelFname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(508, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "Name - ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel9
            // 
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 130);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(20, 268);
            this.panel9.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.posiwarn2);
            this.panel7.Controls.Add(this.posiwarn1);
            this.panel7.Controls.Add(this.gunaButton2);
            this.panel7.Controls.Add(this.selecPosition);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 90);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(528, 40);
            this.panel7.TabIndex = 3;
            // 
            // posiwarn2
            // 
            this.posiwarn2.Dock = System.Windows.Forms.DockStyle.Top;
            this.posiwarn2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posiwarn2.ForeColor = System.Drawing.Color.Red;
            this.posiwarn2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.posiwarn2.Location = new System.Drawing.Point(394, 19);
            this.posiwarn2.Name = "posiwarn2";
            this.posiwarn2.Size = new System.Drawing.Size(134, 19);
            this.posiwarn2.TabIndex = 5;
            // 
            // posiwarn1
            // 
            this.posiwarn1.Dock = System.Windows.Forms.DockStyle.Top;
            this.posiwarn1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posiwarn1.ForeColor = System.Drawing.Color.Red;
            this.posiwarn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.posiwarn1.Location = new System.Drawing.Point(394, 0);
            this.posiwarn1.Name = "posiwarn1";
            this.posiwarn1.Size = new System.Drawing.Size(134, 19);
            this.posiwarn1.TabIndex = 4;
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(260, 0);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(134, 40);
            this.gunaButton2.TabIndex = 3;
            this.gunaButton2.Text = "Change";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // selecPosition
            // 
            this.selecPosition.BackColor = System.Drawing.Color.Transparent;
            this.selecPosition.BaseColor = System.Drawing.Color.White;
            this.selecPosition.BorderColor = System.Drawing.Color.Silver;
            this.selecPosition.Dock = System.Windows.Forms.DockStyle.Left;
            this.selecPosition.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.selecPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selecPosition.FocusedColor = System.Drawing.Color.Empty;
            this.selecPosition.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.selecPosition.ForeColor = System.Drawing.Color.Black;
            this.selecPosition.FormattingEnabled = true;
            this.selecPosition.ItemHeight = 34;
            this.selecPosition.Items.AddRange(new object[] {
            "Super Admin",
            "Normal Admin"});
            this.selecPosition.Location = new System.Drawing.Point(20, 0);
            this.selecPosition.Name = "selecPosition";
            this.selecPosition.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.selecPosition.OnHoverItemForeColor = System.Drawing.Color.White;
            this.selecPosition.Size = new System.Drawing.Size(240, 40);
            this.selecPosition.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(20, 40);
            this.panel8.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 65);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(528, 25);
            this.panel6.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(528, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Position Change - ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.nicwarn2);
            this.panel4.Controls.Add(this.nicwarn1);
            this.panel4.Controls.Add(this.gunaButton1);
            this.panel4.Controls.Add(this.txtNic);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 25);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(528, 40);
            this.panel4.TabIndex = 1;
            // 
            // nicwarn2
            // 
            this.nicwarn2.Dock = System.Windows.Forms.DockStyle.Top;
            this.nicwarn2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicwarn2.ForeColor = System.Drawing.Color.Red;
            this.nicwarn2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nicwarn2.Location = new System.Drawing.Point(394, 19);
            this.nicwarn2.Name = "nicwarn2";
            this.nicwarn2.Size = new System.Drawing.Size(134, 19);
            this.nicwarn2.TabIndex = 4;
            // 
            // nicwarn1
            // 
            this.nicwarn1.Dock = System.Windows.Forms.DockStyle.Top;
            this.nicwarn1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nicwarn1.ForeColor = System.Drawing.Color.Red;
            this.nicwarn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nicwarn1.Location = new System.Drawing.Point(394, 0);
            this.nicwarn1.Name = "nicwarn1";
            this.nicwarn1.Size = new System.Drawing.Size(134, 19);
            this.nicwarn1.TabIndex = 3;
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(260, 0);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(134, 40);
            this.gunaButton1.TabIndex = 2;
            this.gunaButton1.Text = "Load";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // txtNic
            // 
            this.txtNic.BaseColor = System.Drawing.Color.White;
            this.txtNic.BorderColor = System.Drawing.Color.Silver;
            this.txtNic.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNic.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtNic.FocusedBaseColor = System.Drawing.Color.White;
            this.txtNic.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtNic.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtNic.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.txtNic.Location = new System.Drawing.Point(20, 0);
            this.txtNic.Name = "txtNic";
            this.txtNic.PasswordChar = '\0';
            this.txtNic.SelectedText = "";
            this.txtNic.Size = new System.Drawing.Size(240, 40);
            this.txtNic.TabIndex = 1;
            this.txtNic.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(20, 40);
            this.panel5.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(528, 25);
            this.panel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(528, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Admin NIC No. -";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SuperUpdateAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1071, 398);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "SuperUpdateAdmin";
            this.Text = "SuperUpdateAdmin";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adminDataView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaDataGridView adminDataView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI.WinForms.GunaTextBox txtNic;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private Guna.UI.WinForms.GunaComboBox selecPosition;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.Label labelPosition;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelLname;
        private System.Windows.Forms.Label labelMname;
        private System.Windows.Forms.Label labelFname;
        private System.Windows.Forms.Label posiwarn2;
        private System.Windows.Forms.Label posiwarn1;
        private System.Windows.Forms.Label nicwarn2;
        private System.Windows.Forms.Label nicwarn1;
    }
}