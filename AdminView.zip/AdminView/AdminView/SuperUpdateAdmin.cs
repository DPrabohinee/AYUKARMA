﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AdminView
{
    public partial class SuperUpdateAdmin : Form
    {
        SQLClass sql = new SQLClass();
        Calculations cal = new Calculations();
        Message msg = new Message();

        private SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1G3ODQ5;Initial Catalog=ayukarma;Integrated Security=True");

        public SuperUpdateAdmin()
        {
            InitializeComponent();
            loadAdminData();
        }

        #region Cleaning Section
        private void clearNicWarning()
        {
            nicwarn1.Text = null;
            nicwarn2.Text = null;
            clearFields();
        }

        private void clearPositionWarning()
        {
            posiwarn1.Text = null;
            posiwarn2.Text = null;
        }

        private void clearFields()
        {
            labelPosition.Text = "current posision";
            labelFname.Text = "first name";
            labelMname.Text = "middle name";
            labelLname.Text = "last name";
        }
        #endregion

        #region Data Load Section
        private void loadData()
        {
            clearNicWarning();
            clearFields();
            clearPositionWarning();
            string[] s = null;
            string nic = txtNic.Text;
            Boolean t1 = cal.checkNIC(nic);
            if(t1 == true)
            { 
                s = sql.getSuperUpdateAdminData(nic);
                int t = int.Parse(s[0]);
                if(t == 1)
                {
                    labelFname.Text = s[1];
                    labelMname.Text = s[2];
                    labelLname.Text = s[3];
                    labelPosition.Text = s[4];
                }
                else if(t == 0)
                { nicwarn1.Text = "* Invalid NIC"; }
            }
            else if(t1 == false)
            { nicwarn1.Text = "* Invalid NIC"; }
        }

        private void loadAdminData()
        {
            string que = "select nicno as NIC_No, fname as First_Name,lname as Last_Name from admins";
            string table = "admins";
            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                adminDataView.DataSource = ds;
                adminDataView.DataMember = table;
            }
            catch (Exception e)
            {
                string x = Convert.ToString(e);
                msg.invalid_data(x);
            }
            finally
            {
                con.Close();
            }
        }
        #endregion

        #region Function Section
        private void changePosition()
        {
            clearPositionWarning();
            int t = sql.setSuperUpdateAdminPosition(txtNic.Text, selecPosition.Text);
            if(t == 1)
            {
                loadData();
                loadAdminData();
            }
            else
            {
                posiwarn1.Text = "* Invalid Change";
            }
        }
        #endregion

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            changePosition();
        }
    }
}
