
create database ayukarma

use ayukarma

CREATE TABLE ADMINS
(
    AdminID varchar(8) CHECK (AdminID LIKE 'AID_____'), 
    FName varchar(20) NOT NULL ,	
    MName varchar(20) NULL,
    LName varchar(20) NOT NULL ,
    NICNo varchar(10) NOT NULL CHECK (NICNo LIKE '_________v'), 
	Dob date NOT NULL,
    AADLine1 varchar(30) NOT NULL ,
	AADLine2 varchar(30) NOT NULL ,
	AADLine3 varchar(20) DEFAULT('_'),
	Email varchar(100) not null,
    PRIMARY KEY(AdminID)
);

select * from admins
delete admins
drop table admins

create table admindetails
(
	NICNo varchar(10) CHECK (NICNo LIKE '_________v'),
	Password varchar (150) NULL,
	Position varchar(10) NULL,
	Temp int  DEFAULT(0)
)

create table selectedData
(
	nicno varchar(10) CHECK (NICNo LIKE '_________v')
)

select * from admindetails
delete admindetails
drop table admindetails

CREATE TABLE adminHistory
(
    ID int identity(1,1) not null, 
    FName varchar(20) NOT NULL ,	
    MName varchar(20) NULL,
    LName varchar(20) NOT NULL ,
    NICNo varchar(10) NOT NULL CHECK (NICNo LIKE '_________v'), 
	Dob date NOT NULL,
    AADLine1 varchar(30) NOT NULL ,
	AADLine2 varchar(30) NOT NULL ,
	AADLine3 varchar(20) DEFAULT('_'),
	Email varchar(100) not null,
    PRIMARY KEY(ID)
);

create table systemdetails
(
	Date varchar(30) not null,
	Email varchar(100) not null,
	Password varchar(150) not null,
	Responsible varchar(8) not null
)

select * from systemdetails
delete systemdetails
drop table systemdetails

create table AdminTelephone
(
	
)

CREATE TABLE USERS(
	UserID int identity  (1,1) NOT NULL,
   NICNo varchar(10) NOT NULL UNIQUE CHECK (NICNo LIKE '_________v'),
   FName varchar(20)NOT NULL ,
   MName varchar(20) NULL,
   LName varchar(20)NOT NULL ,
   UADLine1 varchar(30) NOT NULL ,                      
   UADLine2 varchar(30) NOT NULL ,						
   UADLine3 varchar(20) DEFAULT('_') ,
   Username varchar(20) NOT NULL ,
   Password nvarchar (500) NOT NULL ,
   Gender varchar(6) NOT NULL ,
   Telephone bigint NOT NULL CHECK (Telephone between 100000000 and 999999999),
   Email VARCHAR (30) NOT NULL, 
   Position int NOT NULL DEFAULT('0'),
   PRIMARY KEY(UserID)
);

CREATE TABLE usersHistory(
	UserID int identity  (1,1) NOT NULL,
	NICNo varchar(10) NOT NULL UNIQUE CHECK (NICNo LIKE '_________v'),
	FName varchar(20)NOT NULL ,
	MName varchar(20) NULL,
	LName varchar(20)NOT NULL ,
	UADLine1 varchar(30) NOT NULL ,                      
	UADLine2 varchar(30) NOT NULL ,						
	UADLine3 varchar(20) DEFAULT('_') ,
	Username varchar(20) NOT NULL ,
	Password nvarchar (500) NOT NULL ,
	Gender varchar(6) NOT NULL ,
	Telephone bigint NOT NULL CHECK (Telephone between 100000000 and 999999999),
	Email VARCHAR (30) NOT NULL, 
	Position int NOT NULL,
	PRIMARY KEY(UserID)
);

create table userBlackList
(
	userID int identity (1,1) not null,
	NICNo varchar(10) NOT NULL UNIQUE CHECK (NICNo LIKE '_________v')
)

CREATE TABLE SystemUsage(
	ID int identity(1,1) NOT NULL,
	Date date, 
	Weblogin int, 
	Webtransaction int, 
	Desktoplogin int,
	Desktoptransaction int,
	Webselling int,
	Desktopselling int,
	WebsBuying int,
	DesktopBuying int,
	WebSpecialorders int,
	DesktopSpecialorders int,
	PRIMARY KEY (ID)
);

CREATE TABLE UserActivitylog(
	LoginID int Identity(1,1) NOT NULL ,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	LoginDate varchar(10) NOT NULL,
	LoginTime varchar(8) NOT NULL,
	LogoutTime varchar(8) DEFAULT NULL,
	PRIMARY KEY (LoginID),
);

CREATE TABLE AdminActivitylog(
	LoginID int Identity(1,1) NOT NULL ,
	AdminID varchar(8) FOREIGN KEY REFERENCES ADMINS (AdminID),
	LoginDate varchar(10) NOT NULL,
	LoginTime varchar(8) NOT NULL,
	LogoutTime varchar(8) DEFAULT NULL,
	PRIMARY KEY (LoginID),
);

drop table AdminActivitylog

CREATE TABLE Orders(
	OrderID int Identity(1,1) NOT NULL ,
	ProductName varchar (100) NOT NULL,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	Unit_price float NOT NULL,
	Totalprice float NOT NULL,
	Date date NOT NULL,
	Quantity int NOT NULL,
	PRIMARY KEY(OrderID)
);

CREATE TABLE SpecialOrders(	
	SOrderID int Identity(1,1) NOT NULL ,
	ProductName varchar (100) NOT NULL,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	Date date NOT NULL,
	Quantity int NOT NULL,
	DeadLine date NOT NULL,
	PRIMARY KEY(SOrderID)
);

CREATE TABLE PastSpecialOrders(	
	SOrderID int Identity(1,1) NOT NULL ,
	ProductName varchar (100) NOT NULL,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	Date date NOT NULL,
	Quantity int NOT NULL,
	DeadLine date NOT NULL,
	PRIMARY KEY(SOrderID)
);

CREATE TABLE Featured(
    ID int,
    ItemName varchar(100),
    ImageName varchar(100),
    Price float (4),
    Unit varchar(15)
);

INSERT INTO Featured(ID,ItemName,ImageName,Price,Unit)
VALUES
(1,'Coconut Oil','bottle','660','piece'),
(2,'Herbal Shampoo','shampoo','850','piece'),
(3,'Ayukarma Soap','soap','40','piece'),
(4,'Acne Facewash','tube','300','piece'),
(5,'Venival Geta','venival','2','gram'),
(6,'Dried Hibiscus','hibiscus','3','gram'),
(7,'Dried Tumeric','tumeric','17','gram'),
(8,'Coriander Seeds','coriander','1','gram');
 
CREATE TABLE Products(
	ID int Identity (1,1) NOT NULL,
	NAME varchar (50) NOT NULL,
	Description nvarchar (500),
	Price float (4),
	ImageName varchar(100),
	Category varchar (50),
	TAGS varchar (500),
	PRIMARY KEY(ID)
);

 
CREATE TABLE RawMaterials(
	ID int Identity (1,1) NOT NULL,
	NAME varchar (50) NOT NULL,
	Description varchar (500),
	Price float (4),
	ImageName varchar(100),
	Category varchar (50),
	TAGS varchar (500),
	PRIMARY KEY(ID)
);


CREATE TABLE Selling(
	SellingID int Identity(1,1) NOT NULL ,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	Item varchar(50) NOT NULL,
	Category varchar(50) NOT NULL,
	Price float NOT NULL,
	Quantity varchar(20) not null ,
	Unit varchar(10) not null,
	Address varchar (100) NOT NULL,
	Telephone bigint NOT NULL CHECK (Telephone between 100000000 and 999999999),
	ImageName1 varchar(100),
	ImageName2 varchar(100),
	ImageName3 varchar(100),
	ImageName4 varchar(100),
	ImageName5 varchar(100),
	PRIMARY KEY(SellingID)
);


CREATE TABLE PastSelling(
	SellingID int Identity(1,1) NOT NULL ,
	UserID int FOREIGN KEY REFERENCES USERS (UserID),
	Item varchar(50) NOT NULL,
	Category varchar(50) NOT NULL,
	Price float NOT NULL,
	Quantity varchar(20) not null ,
	Unit varchar(10) not null,
	Address varchar (100) NOT NULL,
	Telephone bigint NOT NULL CHECK (Telephone between 100000000 and 999999999),
	ImageName1 varchar(100),
	ImageName2 varchar(100),
	ImageName3 varchar(100),
	ImageName4 varchar(100),
	ImageName5 varchar(100),
	PRIMARY KEY(SellingID)
);


INSERT INTO Featured(ID,ItemName,ImageName,Price,Unit)
VALUES
(1,'Coconut Oil','bottle','660','piece'),
(2,'Herbal Shampoo','shampoo','850','piece'),
(3,'Ayukarma Soap','soap','40','piece'),
(4,'Acne Facewash','tube','300','piece'),
(5,'Venival Geta','venival','2','gram'),
(6,'Dried Hibiscus','hibiscus','3','gram'),
(7,'Dried Tumeric','tumeric','17','gram'),
(8,'Coriander Seeds','coriander','1','gram');


insert into admindetails values
('123456789v','abc123','super',0),
('987654321v','cba123','normal',0)

insert into admindetails(nicno,position) values
('123456789v','super'),
('987654321v','normal')

select id,Docname as doctor_name from Doctor

create table test 
(
	id bigint,
	name varchar(20)
)

drop table test

insert into test values 
(5,'a'),
(2,'b'),
(8,'c'),
(10,'d'),
(3,'e'),
(11,'f'),
(1,'g'),
(6,'h'),
(4,'j'),
(6,'k')



select * from test
select count(id) from test where name = 'a'
select name as Fname,count(id) as con from test group by name
select sum(id) from test

create table test1 
(
	id bigint,
	id2 bigint,
	name varchar(20)
)

drop table test1

insert into test2 values 
(5,6,'a'),
(2,7,'b'),
(8,4,'c'),
(10,8,'d'),
(3,9,'e'),
(11,10,'f'),
(1,3,'g'),
(6,4,'h'),
(4,11,'j'),
(6,9,'k')

select * from test1
select count(id) from test1 where name = 'a'
select name as Fname,count(id) as con from test1 group by name
select name,sum(id), sum(id2) from test1 group by name
select name,(sum(id)+sum(id2)) as total from test1 group by name
select id2,count(id) from test1 group by id2,name
create view test3 as
select name,id,id2 from test1 where name = 'a'
select * from test3
select id2,count(id) from test3 group by id2
drop view test3

select id,id2,name,(select name from test) from test1

create table test2 
(
	id bigint null,
	id2 bigint null,
	name varchar(20) null
)

insert into test2(id,id2)
(select id,id2 from test1)

select * from test2
delete test2

delete from test2 
where test2.id in (select test1.id2 from test1)

select t1.id,t2.id2
from test as t1
 join test1 as t2
on t1.id = t2.id