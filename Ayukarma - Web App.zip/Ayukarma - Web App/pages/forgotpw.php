
<!--INCLUDED THE DATABASE CONNECTON-->
<?php include 'database.php'; ?>


<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="../javascript/javascript.js"></script>
  <link rel="icon" href="../images/ayukarmaicon.png" type="image/icon type">
  <link rel="stylesheet" type="text/css" href="../css/css.css">
    <title>Forgot Password | මුරපදය අමතකයි</title>
</head>
<body>
 
	<center>
		<h4 class="sent-notification"></h4>

<!--PASSWORD RENEWAL REQUEST FORM-->    

		<form method="post" id="myForm" id="forgotpw">
      <img class="forgotpw" src="../images/ayukarmalogo2.png">
      <p class="forgotpw">Get password reset email<br>මුරපදය යළි පිහිටුවීම සදහා විද්‍යුත් තැපෑල ලිපිනය ලබා ගන්න</p>

    </center>
      <table class="forgotpw">
        <tr>
          <td>Enter your username.<br><p>ඔබගේ පරිශීලක නාමය ඇතුළත් කරන්න</p></td>
        </tr>
        <tr>
          <td><input id="name" type="text" name="uname" placeholder="Enter your username" required="" /></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <td>Enter your user account's verified email address.<br><p>ඔබගේ පරිශීලක ගිණුමේ සත්‍යාපනය සදහා විද්‍යුත් තැපැල් ලිපිනය ඇතුළත් කරන්න.</p></td>
        </tr>
        <tr>
          <td><input id="email" type="text" name="email" placeholder="Enter your email" required="" /></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <td><input type="submit" name="pwsubmitbtn" class="forgotpwbtn" value="SUBMIT | ඉදිරිපත් කරන්න" required="" /></td>
        </tr>
      </table>
		</form>


	<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script type="text/javascript">
        function sendEmail() {
            var name = $("#name");
            var email = $("#email");
            var subject = $("#subject");
            var body = $("#body");

            if (isNotEmpty(name) && isNotEmpty(email) && isNotEmpty(subject) && isNotEmpty(body)) {
                $.ajax({
                   url: 'sendEmail.php',
                   method: 'POST',
                   dataType: 'json',
                   data: {
                       name: name.val(),
                       email: email.val(),
                       subject: subject.val(),
                       body: body.val()
                   }, success: function (response) {
                        $('#myForm')[0].reset();
                        $('.sent-notification').text("Message Sent Successfully.");
                   }
                });
            }
        }

        function isNotEmpty(caller) {
            if (caller.val() == "") {
                caller.css('border', '1px solid red');
                return false;
            } else
                caller.css('border', '');

            return true;
        }
    </script>

<!--CHECKS WETHER THE EMAIL EXISTS AND WETHER THE USERNAME CORRESSPONDS TO THE EMAIL-->    

        <?php

        if (isset($_POST['pwsubmitbtn'])) 
        {
          $uname = $_POST['uname'];
          $email = $_POST['email'];

          $sql = "SELECT Email FROM USERS WHERE Username = '$uname'";
          $stmt = sqlsrv_query( $conn, $sql);  
          $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_NUMERIC);

          if ($row == true) 
          {
            if ($row[0] == $email) 
            {              
              echo "<script> sendEmail(); </script>";
              echo "<script> alert('done done done') </script>";
            }
            else
            {
              echo "<script> alert('Email mismatch') </script>";
            }
            
          }
        }

          

       ?>

</body>
</html>