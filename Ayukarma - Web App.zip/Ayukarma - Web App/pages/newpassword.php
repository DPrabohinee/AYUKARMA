
<!--INCLUDED THE DATABASE CONNECTON-->
<?php include 'database.php'; ?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script type="text/javascript" src="../javascript/javascript.js"></script>
  <link rel="icon" href="../images/ayukarmaicon.png" type="image/icon type">
  <link rel="stylesheet" type="text/css" href="../css/css.css">
    <title>New Password | නව මුරපදය</title>
</head>
<body>
	<center>

	<form method="post" id="newpw">
      <img class="forgotpw" src="../images/ayukarmalogo2.png">
      <p class="forgotpw">Reset your password | ඔබගේ මුරපදය නැවත සකසන්න</p>

    </center>
      <table class="newpw">
        <tr>
          <td>Enter your username.<br><p>ඔබගේ පරිශීලක නාමය ඇතුළත් කරන්න.</p></td>
        </tr>
        <tr>
          <td><input type="text" name="username" placeholder="Enter your username" required="" /></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <td>Enter new password.<br><p>නව මුරපදය ඇතුළත් කරන්න.</p></td>
        </tr>
        <tr>
          <td><input type="password" name="password" placeholder="Enter new password" required="" /></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <td>Re-enter password.<br><p>මුරපදය යළි ඇතුළු කරන්න.</p></td>
        </tr>
        <tr>
          <td><input type="password" name="passwordx" placeholder="Re-enter password" required="" /></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <td><center><input type="reset" name="newpwresetbtn" class="newpwbtn" value="RESET | යළි පිහිටුවන්න" /></center></td>
      	</tr>
      	<tr>
      		<td><center><input type="Submit" name="newpwsubmitbtn" class="newpwbtn" value="SUBMIT | ඇතුලත් කරන්න"></center></td>          
        </tr>
      </table>
		</form>

		<?php

		if (isset($_POST["newpwsubmitbtn"]))
		{
	
			$count = 0;
			$username= $_POST['username'];
			$password= $_POST['password'];
			$passwordx =$_POST['passwordx'];
			$password1 = md5($password);

			if ($password == $passwordx) 
			{
				$tsql = "UPDATE USERS SET Password = '$password1' WHERE Username = '$username'";  

					if (sqlsrv_query($conn, $tsql) == true) 
					{  
					    echo "<script>alert('Password Successfully changed !\\nමුරපදය සාර්ථකව වෙනස් විය !'); loadPage(2);</script>";  
					}
					else 	 
					{  
						echo "<script>alert('Password change failed. Try again. If not contact the Admins.\\nමුරපද වෙනස් කිරීම අසාර්ථක විය. නැවත උත්සහා කරන්න. එසේ නොවේ නම්, පරිපාලකයින් අමතන්න.</script>";  
					}  
			}
			else
			{
				echo "<script type='text/javascript'>alert('Your password is not matched !\\nඔබගේ මුරපදය නොගැලපේ !');</script>'";
			}

		}

	?>  




</body>
</html>